<?php
// ================================================================
//  CALVIN FOOD — index.php  v3 (Images corrigées + Lucide icons)
// ================================================================

$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "";
$DB_NAME = "calvinfood";

define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('UPLOAD_URL', 'uploads/');

if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);

try {
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER, $DB_PASS,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
         PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
} catch (PDOException $e) {
    die("<div style='font-family:sans-serif;padding:40px;background:#fff'>
    <h2 style='color:#e74c3c'>Erreur de connexion MySQL</h2>
    <p>".$e->getMessage()."</p>
    <p>Vérifiez que WampServer est démarré et que la base <b>calvinfood</b> existe dans phpMyAdmin.</p>
    </div>");
}

session_start();

// ── AUTO-SETUP ────────────────────────────────────────────────────
try {
    $cols = $pdo->query("SHOW COLUMNS FROM plats")->fetchAll(PDO::FETCH_COLUMN, 0);
    foreach(['image_url VARCHAR(255)','est_disponible TINYINT(1) DEFAULT 1',
             'est_populaire TINYINT(1) DEFAULT 0','temps_prep INT DEFAULT 15',
             'categorie_id INT DEFAULT NULL'] as $colDef) {
        $colName = explode(' ',$colDef)[0];
        if (!in_array($colName,$cols))
            $pdo->exec("ALTER TABLE plats ADD COLUMN $colDef");
    }
    $uCols = $pdo->query("SHOW COLUMNS FROM utilisateurs")->fetchAll(PDO::FETCH_COLUMN, 0);
    if (!in_array('photo_profil',$uCols))
        $pdo->exec("ALTER TABLE utilisateurs ADD COLUMN photo_profil VARCHAR(255) DEFAULT NULL");

    $nbDispo=(int)$pdo->query("SELECT COUNT(*) FROM plats WHERE est_disponible=1")->fetchColumn();
    $nbTotal=(int)$pdo->query("SELECT COUNT(*) FROM plats")->fetchColumn();
    if ($nbTotal>0 && $nbDispo===0) $pdo->exec("UPDATE plats SET est_disponible=1");

    if ((int)$pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn()===0) {
        $pdo->exec("INSERT INTO categories(nom,icone,ordre,est_active) VALUES
            ('Plats Africains','PA',1,1),('Grillades','GR',2,1),
            ('Poissons','PO',3,1),('Sandwichs','SF',4,1),
            ('Pizzas','PI',5,1),('Boissons','BO',6,1)");
    }
    if ($nbTotal===0) {
        $cats=$pdo->query("SELECT id FROM categories ORDER BY ordre")->fetchAll(PDO::FETCH_COLUMN);
        while(count($cats)<6) $cats[]=$cats[0]??1;
        list($c1,$c2,$c3,$c4,$c5,$c6)=$cats;
        $st=$pdo->prepare("INSERT INTO plats(categorie_id,nom,description,prix,temps_prep,icone,est_disponible,est_populaire) VALUES(?,?,?,?,?,?,1,?)");
        foreach([
            [$c1,'Riz Sauce Feuille','Riz blanc avec sauce feuilles de manioc et viande',25000,20,'PA',1],
            [$c1,'Riz Gras au Poulet','Riz cuit dans sauce tomate avec poulet entier',30000,25,'PA',1],
            [$c1,'To Sauce Gombo','To de mais avec sauce gombo et poisson fume',20000,20,'PA',0],
            [$c2,'Poulet Braise Entier','Poulet entier marine braise au charbon',45000,40,'GR',1],
            [$c2,'Brochettes de Mouton','Brochettes aux epices africaines',35000,25,'GR',1],
            [$c2,'Poulet en Morceaux','Morceaux de poulet braise sauce pimentee',30000,30,'GR',0],
            [$c3,'Barracuda Braise','Barracuda frais braise sauce tomate',40000,30,'PO',1],
            [$c3,'Capitaine Frit','Filet de capitaine pane frit avec frites',38000,25,'PO',0],
            [$c3,'Thieboudienne','Riz au poisson senegalais aux legumes',32000,35,'PO',1],
            [$c4,'Sandwich Poulet','Baguette avec poulet grille sauce maison',15000,10,'SF',1],
            [$c4,'Burger Calvin Special','Double steak fromage fondu bacon',20000,15,'SF',1],
            [$c5,'Pizza Poulet BBQ','Sauce BBQ poulet grille oignons mozzarella',40000,25,'PI',1],
            [$c5,'Pizza Margherita','Sauce tomate mozzarella basilic',35000,25,'PI',0],
            [$c6,'Jus de Bissap','Jus de fleurs hibiscus frais sucre',8000,5,'BO',1],
            [$c6,'Jus de Gingembre','Jus de gingembre frais legerement sucre',8000,5,'BO',0],
            [$c6,'Eau Minerale','Eau minerale fraiche 1.5L',5000,2,'BO',0],
            [$c6,'Coca-Cola Fanta','Boisson gazeuse 33cl fraiche',6000,2,'BO',0],
        ] as $p) $st->execute($p);
    }
    // Créer les tables manquantes si nécessaire
    $existingTables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('commandes', $existingTables)) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS commandes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            numero_commande VARCHAR(20) UNIQUE,
            client_id INT,
            mode_livraison ENUM('livraison','sur_place','emporter') DEFAULT 'sur_place',
            statut ENUM('en_attente','confirme','en_preparation','pret','en_livraison','livre','annule') DEFAULT 'en_attente',
            montant_total INT NOT NULL DEFAULT 0,
            methode_paiement ENUM('orange_money','mtn_momo','especes','virement') DEFAULT 'especes',
            statut_paiement ENUM('non_paye','paye','rembourse') DEFAULT 'non_paye',
            ref_paiement VARCHAR(100),
            adresse_livraison TEXT,
            telephone_livraison VARCHAR(30),
            notes_client TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (client_id) REFERENCES utilisateurs(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
    if (!in_array('commande_details', $existingTables)) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS commande_details (
            id INT AUTO_INCREMENT PRIMARY KEY,
            commande_id INT NOT NULL,
            plat_id INT,
            nom_plat VARCHAR(150),
            prix_unitaire INT NOT NULL DEFAULT 0,
            quantite INT NOT NULL DEFAULT 1,
            sous_total INT NOT NULL DEFAULT 0,
            FOREIGN KEY (commande_id) REFERENCES commandes(id) ON DELETE CASCADE,
            FOREIGN KEY (plat_id) REFERENCES plats(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
    if (!in_array('messages', $existingTables)) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            commande_id INT,
            expediteur_id INT,
            role_expediteur ENUM('admin','client') NOT NULL,
            contenu TEXT NOT NULL,
            lu TINYINT(1) DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (commande_id) REFERENCES commandes(id) ON DELETE CASCADE,
            FOREIGN KEY (expediteur_id) REFERENCES utilisateurs(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
} catch(PDOException $ignored){}

function isAdmin()    { return isset($_SESSION['role']) && $_SESSION['role']==='admin'; }
function isLoggedIn() { return isset($_SESSION['user_id']); }

function json_out($ok,$msg='',$data=null) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success'=>$ok,'message'=>$msg,'data'=>$data],JSON_UNESCAPED_UNICODE);
    exit;
}

function fmtGNF($n) {
    $n=(int)$n;
    if($n>=1000000) return number_format($n/1000000,1).'M GNF';
    if($n>=1000)    return round($n/1000).'K GNF';
    return $n.' GNF';
}
function fmtDate($d) { return $d?date('d/m/Y H:i',strtotime($d)):'—'; }

// ── UPLOAD IMAGE ROBUSTE ──────────────────────────────────────────
// Accepte JPG, PNG, WEBP, GIF, HEIC, AVIF, BMP
// Convertit tout en JPEG via GD pour maximiser la compatibilité
function uploadImage($file, $prefix='img') {
    if (!$file || $file['error'] !== UPLOAD_ERR_OK)
        return ['ok'=>false,'msg'=>'Erreur upload ('.$file['error'].')'];

    $maxSize = 10 * 1024 * 1024; // 10MB
    if ($file['size'] > $maxSize)
        return ['ok'=>false,'msg'=>'Image trop grande (max 10MB).'];

    // Détecter le vrai type MIME (ignorer l'extension)
    $finfo    = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    $allowedMimes = [
        'image/jpeg','image/jpg','image/pjpeg',
        'image/png','image/x-png',
        'image/webp',
        'image/gif',
        'image/bmp','image/x-bmp',
        'image/avif',
        'image/heic','image/heif',
    ];

    // Si MIME inconnu, essayer de lire avec GD
    $imgResource = null;

    if (in_array($mimeType, $allowedMimes) || str_starts_with($mimeType,'image/')) {
        // Essayer de créer une ressource GD
        if (function_exists('imagecreatefromstring')) {
            $rawData = file_get_contents($file['tmp_name']);
            $imgResource = @imagecreatefromstring($rawData);
        }
    }

    $nomFichier = $prefix.'_'.time().'_'.rand(1000,9999).'.jpg';
    $dest       = UPLOAD_DIR.$nomFichier;

    if ($imgResource !== false && $imgResource !== null) {
        // Convertir en JPEG via GD (marche pour JPG, PNG, WEBP, GIF, BMP)
        $w = imagesx($imgResource);
        $h = imagesy($imgResource);
        // Redimensionner si trop grand (max 1200px)
        if ($w > 1200) {
            $newH = (int)($h * 1200 / $w);
            $resized = imagecreatetruecolor(1200, $newH);
            // Fond blanc pour les PNG transparents
            imagefill($resized, 0, 0, imagecolorallocate($resized, 255, 255, 255));
            imagecopyresampled($resized, $imgResource, 0, 0, 0, 0, 1200, $newH, $w, $h);
            imagedestroy($imgResource);
            $imgResource = $resized;
        }
        $ok = imagejpeg($imgResource, $dest, 85);
        imagedestroy($imgResource);
        if (!$ok) return ['ok'=>false,'msg'=>'Échec de conversion de l\'image.'];
    } else {
        // Fallback : copie directe sans conversion
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext,['jpg','jpeg','png','webp','gif','bmp']))
            return ['ok'=>false,'msg'=>'Format d\'image non reconnu. Utilisez JPG, PNG ou WEBP.'];
        $nomFichier = $prefix.'_'.time().'_'.rand(1000,9999).'.'.$ext;
        $dest = UPLOAD_DIR.$nomFichier;
        if (!move_uploaded_file($file['tmp_name'], $dest))
            return ['ok'=>false,'msg'=>'Échec de l\'enregistrement.'];
    }

    return ['ok'=>true,'url'=>UPLOAD_URL.$nomFichier];
}

// ================================================================
// AJAX
// ================================================================
if (isset($_GET['ajax'])) {
    $action = $_POST['action'] ?? $_GET['action'] ?? '';

    if ($action==='login') {
        $email=trim($_POST['email']??''); $pass=$_POST['password']??'';
        if (!$email||!$pass) json_out(false,'Email et mot de passe requis.');
        $st=$pdo->prepare("SELECT * FROM utilisateurs WHERE email=? LIMIT 1");
        $st->execute([$email]); $u=$st->fetch();
        if (!$u||!password_verify($pass,$u['mot_de_passe'])) json_out(false,'Email ou mot de passe incorrect.');
        $_SESSION['user_id']=$u['id']; $_SESSION['role']=$u['role'];
        $_SESSION['nom']=$u['nom_complet']; $_SESSION['email']=$u['email']; $_SESSION['telephone']=$u['telephone'];
        json_out(true,'',['id'=>$u['id'],'role'=>$u['role'],'nom'=>$u['nom_complet'],
            'email'=>$u['email'],'telephone'=>$u['telephone'],'photo'=>$u['photo_profil']??'']);
    }

    if ($action==='register') {
        $nom=trim($_POST['nom']??''); $email=trim($_POST['email']??'');
        $tel=trim($_POST['telephone']??''); $pass=$_POST['password']??'';
        if (!$nom||!$email||!$pass) json_out(false,'Nom, email et mot de passe obligatoires.');
        if (strlen($pass)<6) json_out(false,'Mot de passe minimum 6 caractères.');
        $chk=$pdo->prepare("SELECT id FROM utilisateurs WHERE email=?"); $chk->execute([$email]);
        if ($chk->fetch()) json_out(false,'Email déjà utilisé.');
        $hash=password_hash($pass,PASSWORD_BCRYPT);
        $pdo->prepare("INSERT INTO utilisateurs(nom_complet,email,telephone,mot_de_passe,role) VALUES(?,?,?,?,'client')")
            ->execute([$nom,$email,$tel,$hash]);
        $id=$pdo->lastInsertId();
        $_SESSION['user_id']=$id; $_SESSION['role']='client';
        $_SESSION['nom']=$nom; $_SESSION['email']=$email; $_SESSION['telephone']=$tel;
        json_out(true,'Compte créé !',['id'=>$id,'role'=>'client','nom'=>$nom,'email'=>$email,'telephone'=>$tel,'photo'=>'']);
    }

    if ($action==='logout') { session_destroy(); json_out(true,'Déconnecté.'); }

    if ($action==='session') {
        if (isLoggedIn()) {
            $st=$pdo->prepare("SELECT photo_profil FROM utilisateurs WHERE id=?");
            $st->execute([$_SESSION['user_id']]); $u=$st->fetch();
            json_out(true,'',['user_id'=>$_SESSION['user_id'],'role'=>$_SESSION['role'],
                'nom'=>$_SESSION['nom'],'email'=>$_SESSION['email'],
                'telephone'=>$_SESSION['telephone']??'','photo'=>$u['photo_profil']??'']);
        } else json_out(false,'Non connecté.');
    }

    // PHOTO PROFIL
    if ($action==='upload_photo_profil') {
        if (!isLoggedIn()) json_out(false,'Non connecté.');
        if (empty($_FILES['photo']['name'])) json_out(false,'Aucune photo sélectionnée.');
        $st=$pdo->prepare("SELECT photo_profil FROM utilisateurs WHERE id=?");
        $st->execute([$_SESSION['user_id']]); $old=$st->fetchColumn();
        if ($old&&file_exists(__DIR__.'/'.$old)) @unlink(__DIR__.'/'.$old);
        $up=uploadImage($_FILES['photo'],'profil');
        if (!$up['ok']) json_out(false,$up['msg']);
        $pdo->prepare("UPDATE utilisateurs SET photo_profil=? WHERE id=?")->execute([$up['url'],$_SESSION['user_id']]);
        json_out(true,'Photo mise à jour !',['photo'=>$up['url']]);
    }

    if ($action==='supprimer_photo') {
        if (!isLoggedIn()) json_out(false,'Non connecté.');
        $st=$pdo->prepare("SELECT photo_profil FROM utilisateurs WHERE id=?");
        $st->execute([$_SESSION['user_id']]); $old=$st->fetchColumn();
        if ($old&&file_exists(__DIR__.'/'.$old)) @unlink(__DIR__.'/'.$old);
        $pdo->prepare("UPDATE utilisateurs SET photo_profil=NULL WHERE id=?")->execute([$_SESSION['user_id']]);
        json_out(true,'Photo supprimée.');
    }

    if ($action==='categories') {
        json_out(true,'',$pdo->query("SELECT * FROM categories WHERE est_active=1 ORDER BY ordre")->fetchAll());
    }

    if ($action==='menu') {
        $catId=(int)($_GET['cat']??0);
        $where='WHERE p.est_disponible=1'; if($catId) $where.=" AND p.categorie_id=$catId";
        $rows=$pdo->query("SELECT p.*,c.nom AS categorie_nom FROM plats p LEFT JOIN categories c ON c.id=p.categorie_id $where ORDER BY p.est_populaire DESC,p.nom")->fetchAll();
        foreach($rows as &$r){$r['prix_formate']=fmtGNF((int)$r['prix']);$r['image_url']=$r['image_url']??'';}
        json_out(true,'',$rows);
    }

    if ($action==='menu_admin') {
        if (!isAdmin()) json_out(false,'Accès refusé.');
        $rows=$pdo->query("SELECT p.*,c.nom AS categorie_nom FROM plats p LEFT JOIN categories c ON c.id=p.categorie_id ORDER BY p.categorie_id,p.nom")->fetchAll();
        foreach($rows as &$r){$r['prix_formate']=fmtGNF((int)$r['prix']);$r['image_url']=$r['image_url']??'';}
        json_out(true,'',$rows);
    }

    if ($action==='plat_create') {
        if (!isAdmin()) json_out(false,'Accès refusé.');
        $nom=trim($_POST['nom']??''); $prix=(int)($_POST['prix']??0);
        if (!$nom||$prix<=0) json_out(false,'Nom et prix obligatoires.');
        $imgUrl=null;
        if (!empty($_FILES['image']['name'])) {
            $up=uploadImage($_FILES['image'],'plat');
            if (!$up['ok']) json_out(false,$up['msg']);
            $imgUrl=$up['url'];
        }
        $pdo->prepare("INSERT INTO plats(categorie_id,nom,description,prix,temps_prep,icone,image_url,est_populaire) VALUES(?,?,?,?,?,?,?,?)")
            ->execute([(int)($_POST['cat']??0),$nom,trim($_POST['desc']??''),$prix,(int)($_POST['temps']??15),trim($_POST['icone']??''),$imgUrl,isset($_POST['populaire'])?1:0]);
        json_out(true,'Plat ajouté !',['id'=>$pdo->lastInsertId()]);
    }

    if ($action==='plat_update') {
        if (!isAdmin()) json_out(false,'Accès refusé.');
        $id=(int)($_POST['id']??0); $nom=trim($_POST['nom']??''); $prix=(int)($_POST['prix']??0);
        if (!$id||!$nom||$prix<=0) json_out(false,'Données invalides.');
        $imgUrl=$_POST['image_actuelle']??null;
        if (!empty($_FILES['image']['name'])) {
            if ($imgUrl&&file_exists(__DIR__.'/'.$imgUrl)) @unlink(__DIR__.'/'.$imgUrl);
            $up=uploadImage($_FILES['image'],'plat');
            if (!$up['ok']) json_out(false,$up['msg']);
            $imgUrl=$up['url'];
        }
        $pdo->prepare("UPDATE plats SET categorie_id=?,nom=?,description=?,prix=?,temps_prep=?,icone=?,image_url=?,est_populaire=?,est_disponible=? WHERE id=?")
            ->execute([(int)($_POST['cat']??0),$nom,trim($_POST['desc']??''),$prix,(int)($_POST['temps']??15),trim($_POST['icone']??''),$imgUrl,isset($_POST['populaire'])?1:0,isset($_POST['disponible'])?1:0,$id]);
        json_out(true,'Plat modifié !');
    }

    if ($action==='plat_toggle') {
        if (!isAdmin()) json_out(false,'Accès refusé.');
        $pdo->prepare("UPDATE plats SET est_disponible=? WHERE id=?")->execute([(int)$_POST['val'],(int)$_POST['id']]);
        json_out(true,'OK');
    }

    if ($action==='plat_delete') {
        if (!isAdmin()) json_out(false,'Accès refusé.');
        $id=(int)($_POST['id']??0);
        $st=$pdo->prepare("SELECT image_url FROM plats WHERE id=?"); $st->execute([$id]); $p=$st->fetch();
        if ($p&&$p['image_url']&&file_exists(__DIR__.'/'.$p['image_url'])) @unlink(__DIR__.'/'.$p['image_url']);
        $pdo->prepare("DELETE FROM plats WHERE id=?")->execute([$id]);
        json_out(true,'Plat supprimé.');
    }

    if ($action==='commandes_list') {
        if (!isLoggedIn()) json_out(false,'Non connecté.');
        $sL=['en_attente'=>'En attente','confirme'=>'Confirmé','en_preparation'=>'En préparation','pret'=>'Prêt','en_livraison'=>'En livraison','livre'=>'Livré','annule'=>'Annulé'];
        $mL=['livraison'=>'Livraison','sur_place'=>'Sur place','emporter'=>'À emporter'];
        $pL=['orange_money'=>'Orange Money','mtn_momo'=>'MTN MoMo','especes'=>'Espèces','virement'=>'Virement'];
        if (isAdmin()) {
            $rows=$pdo->query("SELECT c.*,u.nom_complet,u.telephone AS tel_client,u.photo_profil AS photo_client,GROUP_CONCAT(CONCAT(cd.quantite,'x ',cd.nom_plat) ORDER BY cd.id SEPARATOR ', ') AS resume_plats FROM commandes c LEFT JOIN utilisateurs u ON u.id=c.client_id LEFT JOIN commande_details cd ON cd.commande_id=c.id GROUP BY c.id ORDER BY c.created_at DESC")->fetchAll();
        } else {
            $st=$pdo->prepare("SELECT c.*,GROUP_CONCAT(CONCAT(cd.quantite,'x ',cd.nom_plat) ORDER BY cd.id SEPARATOR ', ') AS resume_plats FROM commandes c LEFT JOIN commande_details cd ON cd.commande_id=c.id WHERE c.client_id=? GROUP BY c.id ORDER BY c.created_at DESC");
            $st->execute([$_SESSION['user_id']]); $rows=$st->fetchAll();
        }
        foreach($rows as &$r){$r['montant_formate']=fmtGNF((int)$r['montant_total']);$r['date_formate']=fmtDate($r['created_at']);$r['statut_label']=$sL[$r['statut']]??$r['statut'];$r['livraison_label']=$mL[$r['mode_livraison']]??$r['mode_livraison'];$r['paiement_label']=$pL[$r['methode_paiement']]??$r['methode_paiement'];}
        json_out(true,'',$rows);
    }

    if ($action==='commandes_stats') {
        if (!isLoggedIn()) json_out(false,'Non connecté.');
        if (isAdmin()) {
            $m=date('Y-m-01');
            $rev=$pdo->query("SELECT COALESCE(SUM(montant_total),0) FROM commandes WHERE statut_paiement='paye' AND created_at>='$m'")->fetchColumn();
            $act=$pdo->query("SELECT COUNT(*) FROM commandes WHERE statut IN('confirme','en_preparation','en_livraison')")->fetchColumn();
            $cli=$pdo->query("SELECT COUNT(*) FROM utilisateurs WHERE role='client'")->fetchColumn();
            $tot=$pdo->query("SELECT COUNT(*) FROM commandes")->fetchColumn();
            $att=$pdo->query("SELECT COUNT(*) FROM commandes WHERE statut='en_attente'")->fetchColumn();
            $attP=$pdo->query("SELECT COALESCE(SUM(montant_total),0) FROM commandes WHERE statut_paiement='non_paye'")->fetchColumn();
            $liv=$pdo->query("SELECT COUNT(*) FROM commandes WHERE mode_livraison='livraison' AND DATE(created_at)=CURDATE()")->fetchColumn();
            json_out(true,'',['revenu_mois'=>fmtGNF((int)$rev),'actives'=>$act,'clients'=>$cli,'total'=>$tot,'en_attente'=>$att,'attente_paiement'=>fmtGNF((int)$attP),'livraisons_jour'=>$liv]);
        } else {
            $st=$pdo->prepare("SELECT COUNT(*) AS total,SUM(statut='livre') AS livrees,SUM(statut IN('confirme','en_preparation','en_livraison')) AS en_cours,COALESCE(SUM(montant_total),0) AS montant_total FROM commandes WHERE client_id=?");
            $st->execute([$_SESSION['user_id']]); $s=$st->fetch(); $s['montant_formate']=fmtGNF((int)$s['montant_total']);
            json_out(true,'',$s);
        }
    }

    if ($action==='commande_create') {
        if (!isLoggedIn()) json_out(false,'Non connecté.');
        $panier=json_decode($_POST['panier']??'[]',true);
        $mode=$_POST['mode']??'sur_place'; $methode=$_POST['methode']??'especes';
        $adresse=trim($_POST['adresse']??''); $tel=trim($_POST['telephone']??''); $notes=trim($_POST['notes']??'');
        if (empty($panier)) json_out(false,'Panier vide.');
        if ($mode==='livraison'&&!$adresse) json_out(false,'Adresse de livraison requise.');
        $total=0; $platsOk=[];
        foreach($panier as $item){
            $p=$pdo->prepare("SELECT id,nom,prix FROM plats WHERE id=? AND est_disponible=1");
            $p->execute([(int)$item['id']]); $pl=$p->fetch();
            if($pl){$qty=max(1,(int)($item['qty']??1));$total+=$pl['prix']*$qty;$platsOk[]=['id'=>$pl['id'],'nom'=>$pl['nom'],'prix'=>$pl['prix'],'qty'=>$qty];}
        }
        if (empty($platsOk)) json_out(false,'Aucun plat valide.');
        $num='CF-'.str_pad(rand(1,9999),4,'0',STR_PAD_LEFT);
        $pdo->prepare("INSERT INTO commandes(numero_commande,client_id,mode_livraison,montant_total,methode_paiement,adresse_livraison,telephone_livraison,notes_client) VALUES(?,?,?,?,?,?,?,?)")
            ->execute([$num,$_SESSION['user_id'],$mode,$total,$methode,$adresse,$tel,$notes]);
        $cid=$pdo->lastInsertId();
        $stD=$pdo->prepare("INSERT INTO commande_details(commande_id,plat_id,nom_plat,prix_unitaire,quantite,sous_total) VALUES(?,?,?,?,?,?)");
        foreach($platsOk as $p) $stD->execute([$cid,$p['id'],$p['nom'],$p['prix'],$p['qty'],$p['prix']*$p['qty']]);
        json_out(true,'Commande passée !',['commande_id'=>$cid,'numero'=>$num,'montant'=>$total,'methode'=>$methode]);
    }

    if ($action==='commande_statut') {
        if (!isAdmin()) json_out(false,'Accès refusé.');
        $valides=['en_attente','confirme','en_preparation','pret','en_livraison','livre','annule'];
        $s=$_POST['statut']??''; if(!in_array($s,$valides)) json_out(false,'Statut invalide.');
        $pdo->prepare("UPDATE commandes SET statut=? WHERE id=?")->execute([$s,(int)$_POST['id']]);
        json_out(true,'Statut mis à jour.');
    }

    if ($action==='commande_payer') {
        if (!isAdmin()) json_out(false,'Accès refusé.');
        $pdo->prepare("UPDATE commandes SET statut_paiement='paye',ref_paiement=? WHERE id=?")->execute([$_POST['ref']??'',(int)$_POST['id']]);
        json_out(true,'Paiement confirmé !');
    }

    if ($action==='commande_ref') {
        if (!isLoggedIn()) json_out(false,'Non connecté.');
        $id=(int)($_POST['id']??0);
        $chk=$pdo->prepare("SELECT id FROM commandes WHERE id=? AND client_id=?"); $chk->execute([$id,$_SESSION['user_id']]);
        if (!$chk->fetch()) json_out(false,'Commande introuvable.');
        $pdo->prepare("UPDATE commandes SET ref_paiement=? WHERE id=?")->execute([$_POST['ref']??'',$id]);
        json_out(true,'Référence soumise !');
    }

    if ($action==='clients_list') {
        if (!isAdmin()) json_out(false,'Accès refusé.');
        $rows=$pdo->query("SELECT u.id,u.nom_complet,u.email,u.telephone,u.quartier,u.ville,u.created_at,u.photo_profil,COUNT(c.id) AS nb_commandes,COALESCE(SUM(c.montant_total),0) AS total_depense FROM utilisateurs u LEFT JOIN commandes c ON c.client_id=u.id WHERE u.role='client' GROUP BY u.id ORDER BY u.created_at DESC")->fetchAll();
        foreach($rows as &$r){$r['total_formate']=fmtGNF((int)$r['total_depense']);$r['date_formate']=fmtDate($r['created_at']);}
        json_out(true,'',$rows);
    }

    if ($action==='profil_get') {
        if (!isLoggedIn()) json_out(false,'Non connecté.');
        $st=$pdo->prepare("SELECT id,nom_complet,email,telephone,quartier,ville,photo_profil FROM utilisateurs WHERE id=?");
        $st->execute([$_SESSION['user_id']]); json_out(true,'',$st->fetch());
    }

    if ($action==='profil_update') {
        if (!isLoggedIn()) json_out(false,'Non connecté.');
        $pdo->prepare("UPDATE utilisateurs SET nom_complet=?,telephone=?,quartier=?,ville=? WHERE id=?")
            ->execute([trim($_POST['nom']??''),trim($_POST['telephone']??''),trim($_POST['quartier']??''),trim($_POST['ville']??'Conakry'),$_SESSION['user_id']]);
        $_SESSION['nom']=trim($_POST['nom']??'');
        json_out(true,'Profil mis à jour !');
    }

    if ($action==='password_change') {
        if (!isLoggedIn()) json_out(false,'Non connecté.');
        $cur=$_POST['current']??''; $new=$_POST['new']??''; $conf=$_POST['confirm']??'';
        if (strlen($new)<6) json_out(false,'Minimum 6 caractères.');
        if ($new!==$conf) json_out(false,'Les mots de passe ne correspondent pas.');
        $st=$pdo->prepare("SELECT mot_de_passe FROM utilisateurs WHERE id=?"); $st->execute([$_SESSION['user_id']]); $u=$st->fetch();
        if (!password_verify($cur,$u['mot_de_passe'])) json_out(false,'Mot de passe actuel incorrect.');
        $pdo->prepare("UPDATE utilisateurs SET mot_de_passe=? WHERE id=?")->execute([password_hash($new,PASSWORD_BCRYPT),$_SESSION['user_id']]);
        json_out(true,'Mot de passe modifié !');
    }

    if ($action==='messages_list') {
        if (!isLoggedIn()) json_out(false,'Non connecté.');
        $cid=(int)($_GET['cid']??$_POST['cid']??0); if (!$cid) json_out(false,'ID requis.');
        $st=$pdo->prepare("SELECT m.*,u.nom_complet AS exp_nom,u.photo_profil AS exp_photo FROM messages m LEFT JOIN utilisateurs u ON u.id=m.expediteur_id WHERE m.commande_id=? ORDER BY m.created_at ASC");
        $st->execute([$cid]); $rows=$st->fetchAll();
        foreach($rows as &$r) $r['heure']=date('H:i',strtotime($r['created_at']));
        $pdo->prepare("UPDATE messages SET lu=1 WHERE commande_id=? AND role_expediteur!=?")->execute([$cid,$_SESSION['role']]);
        json_out(true,'',$rows);
    }

    if ($action==='message_send') {
        if (!isLoggedIn()) json_out(false,'Non connecté.');
        $cid=(int)($_POST['cid']??0); $txt=trim($_POST['contenu']??'');
        if (!$cid||!$txt) json_out(false,'Données manquantes.');
        $pdo->prepare("INSERT INTO messages(commande_id,expediteur_id,role_expediteur,contenu) VALUES(?,?,?,?)")->execute([$cid,$_SESSION['user_id'],$_SESSION['role'],$txt]);
        json_out(true,'',['contenu'=>$txt,'heure'=>date('H:i'),'role_expediteur'=>$_SESSION['role'],'exp_nom'=>$_SESSION['nom']]);
    }

    if ($action==='conversations_list') {
        if (!isAdmin()) json_out(false,'Accès refusé.');
        $rows=$pdo->query("SELECT c.id AS cid,c.numero_commande,u.nom_complet,u.photo_profil,c.statut,(SELECT COUNT(*) FROM messages m WHERE m.commande_id=c.id AND m.lu=0 AND m.role_expediteur='client') AS non_lus,(SELECT contenu FROM messages m2 WHERE m2.commande_id=c.id ORDER BY m2.created_at DESC LIMIT 1) AS dernier_msg FROM commandes c LEFT JOIN utilisateurs u ON u.id=c.client_id ORDER BY c.updated_at DESC LIMIT 20")->fetchAll();
        json_out(true,'',$rows);
    }

    json_out(false,'Action inconnue.');
    exit;
}
// ── FIN AJAX ─────────────────────────────────────────────────────
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Calvin Food — Restaurant Conakry</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Nunito:wght@300;400;500;600;700;800&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<!-- Lucide Icons CDN (professionnels, légers, SVG) -->
<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
<style>
/* ═══════════════════════════════════════════════════
   CALVIN FOOD — Design System v3
   Palette : Blanc ivoire · Vert émeraude · Ambre doré
   Typographie : Fraunces (titres) + Plus Jakarta Sans
   Ambiance : Fraîche, vivante, appétissante, moderne
   ═══════════════════════════════════════════════════ */
:root {
  /* Calvin Food — Palette signature
     Inspiré de la cuisine africaine : terre, épices, verdure,
     chaleur du feu. Ton artisanal, pas corporate.
     Fond : crème chaud / Primaire : vert kaki profond
     Accent : orange brûlé / Détail : cuivre */

  --bg:      #f7f2ea;
  --bg2:     #ffffff;
  --bg3:     #ede8df;
  --card:    #ffffff;
  --edge:    rgba(60,45,25,.1);
  --edge2:   rgba(60,45,25,.05);

  /* Vert kaki — couleur principale */
  --p:       #2d4a2d;
  --p2:      #3a5e3a;
  --p3:      #eef3ee;
  --plight:  rgba(45,74,45,.08);
  --plight:  rgba(45,74,45,.08);

  /* Orange brûlé — accent chaud */
  --a:       #c4531a;
  --a2:      #e06528;
  --abg:     #fdf1ea;

  /* Cuivre doré — détail luxe */
  --cu:      #a0722a;
  --cu2:     #c49240;
  --cubg:    #fdf7ee;

  /* Statuts */
  --ok:      #2e7d32;  --ok-bg:   #e8f5e9;
  --warn:    #e65100;  --warn-bg: #fff3e0;
  --info:    #1565c0;  --info-bg: #e3f2fd;
  --err:     #b71c1c;  --err-bg:  #ffebee;

  /* Texte */
  --t1:  #1c1408;
  --t2:  #3d2e18;
  --t3:  #7a6a55;
  --t4:  #b8a898;

  --r:   9px;
  --rl:  15px;
  --s1:  0 1px 4px rgba(40,25,10,.08);
  --s2:  0 4px 20px rgba(40,25,10,.12);
  --s3:  0 12px 48px rgba(40,25,10,.18);
}

*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }

body {
  font-family: 'Nunito', sans-serif;
  background: var(--bg);
  color: var(--t1);
  min-height: 100vh;
  font-size: 14px;
  line-height: 1.56;
}
body::before {
  content:'';
  position:fixed; inset:0; pointer-events:none; z-index:0;
  background:
    radial-gradient(ellipse at 80% 0%, rgba(196,83,26,.06) 0%, transparent 55%),
    radial-gradient(ellipse at 10% 90%, rgba(45,74,45,.05) 0%, transparent 50%);
}

/* ── TOPBAR ── */
.topbar {
  background: var(--bg2);
  border-bottom: 2px solid var(--bg3);
  height: 62px;
  padding: 0 28px;
  display: flex; align-items:center; justify-content:space-between;
  position: sticky; top:0; z-index:100;
  box-shadow: var(--s1);
}

.brand { display:flex; align-items:center; gap:11px; }
.brand-logo {
  width: 38px; height: 38px; border-radius: 10px;
  background: var(--p);
  display: flex; align-items:center; justify-content:center;
  box-shadow: 0 2px 10px rgba(45,74,45,.3);
}
.brand-logo svg { color:#fff; }
.brand-name {
  font-family: 'Cormorant Garamond', serif;
  font-weight: 700; font-size: 22px;
  color: var(--t1); letter-spacing: -.4px;
  line-height: 1;
}
.brand-name em { color: var(--a); font-style:normal; }
.brand-sub { font-size: 10px; color: var(--t3); letter-spacing: .6px; text-transform:uppercase; }

.topbar-r { display:flex; align-items:center; gap:10px; }

.rbadge {
  font-size: 10.5px; font-weight: 700;
  padding: 3px 10px; border-radius: 20px;
  text-transform: uppercase; letter-spacing: .5px;
}
.rbadge.admin  { background: var(--p3); color: var(--p); border:1.5px solid rgba(45,74,45,.2); font-weight:700; }
.rbadge.client { background: var(--abg); color: var(--a); border:1px solid rgba(196,83,26,.2); font-weight:700; }

.topbar-ava {
  width: 36px; height: 36px; border-radius: 50%;
  background: linear-gradient(135deg, var(--p), var(--p2));
  display: flex; align-items:center; justify-content:center;
  font-weight: 700; font-size: 14px; color: #fff;
  overflow: hidden; cursor: pointer;
  border: 2px solid var(--bg3);
  box-shadow: var(--s1);
  transition: .18s;
}
.topbar-ava:hover { border-color: var(--p); box-shadow: 0 0 0 3px rgba(45,74,45,.15); }
.topbar-ava img { width:100%; height:100%; object-fit:cover; }

/* ── SIDEBAR ── */
.layout { display:flex; min-height:calc(100vh - 62px); }

.sidebar {
  width: 234px;
  background: var(--bg2);
  border-right: 2px solid var(--bg3);
  padding: 18px 10px;
  display: flex; flex-direction:column; gap:1px;
  flex-shrink: 0;
}

.ss {
  font-size: 9.5px; text-transform:uppercase;
  letter-spacing: 1.2px; color: var(--cu);
  padding: 14px 12px 5px; font-weight: 700;
  opacity:.7;
}

.ni {
  display: flex; align-items:center; gap:10px;
  padding: 9px 12px; border-radius: var(--r);
  cursor: pointer; font-size: 13.5px; font-weight: 500;
  color: var(--t2); transition: all .15s; position:relative;
}
.ni:hover { background: rgba(255,255,255,.06); color: var(--t1); }
.ni.active {
  background: rgba(160,114,42,.08); color: var(--cu);
  font-weight: 600;
}
.ni.active::before {
  content:''; position:absolute; left:0; top:25%; bottom:25%;
  width:3px; border-radius:2px; background:var(--cu);
}
.ni .ic { width:18px; display:flex; align-items:center; justify-content:center; }
.ni .ic svg { width:16px; height:16px; }
.ni .nb {
  margin-left:auto; background:var(--a); color:#fff;
  font-size:10px; font-weight:700; padding:1px 6px; border-radius:10px;
}

/* ── MAIN ── */
.main { flex:1; padding:28px; overflow-y:auto; }

.page { display:none; }
.page.active { display:block; animation: fadeUp .2s ease; }
@keyframes fadeUp { from{opacity:0;transform:translateY(6px)} to{opacity:1;transform:translateY(0)} }

.ph {
  margin-bottom: 22px;
  display: flex; align-items:flex-start;
  justify-content:space-between; flex-wrap:wrap; gap:10px;
}
.pt {
  font-family: 'Cormorant Garamond', serif;
  font-size: 26px; font-weight: 700;
  color: var(--t1); letter-spacing: -.4px;
  line-height: 1.2;
}
.ps { color:var(--t3); font-size:13px; margin-top:3px; }

/* ── STAT CARDS ── */
.sg { display:grid; grid-template-columns:repeat(4,1fr); gap:14px; margin-bottom:22px; }
.sc {
  background: var(--card);
  border: 1.5px solid var(--bg3);
  border-radius: var(--rl);
  padding: 20px; position:relative; overflow:hidden;
  box-shadow: var(--s1);
  transition: transform .2s, box-shadow .2s;
}
.sc:hover { transform:translateY(-2px); box-shadow:var(--s2); }
.sc-icon {
  width: 40px; height: 40px; border-radius: 10px;
  display: flex; align-items:center; justify-content:center;
  margin-bottom: 12px;
}
.sc-icon svg { width:20px; height:20px; }
.sc.go .sc-icon { background:var(--cubg); color:var(--cu); }
.sc.gr .sc-icon { background:rgba(160,114,42,.08); color:var(--cu2); }
.sc.ok .sc-icon { background:var(--ok-bg); color:var(--ok); }
.sc.bl .sc-icon { background:var(--info-bg); color:var(--info); }
.sc.go { border-left:3px solid var(--cu); border-top:none; }
.sc.gr { border-left:3px solid var(--p); border-top:none; }
.sc.ok { border-left:3px solid var(--a); border-top:none; }
.sc.bl { border-left:3px solid var(--cu); border-top:none; }
.sl { font-size:11px; color:var(--t3); text-transform:uppercase; letter-spacing:.5px; font-weight:600; }
.sv {
  font-family: 'Cormorant Garamond', serif;
  font-size: 26px; font-weight: 700;
  margin: 5px 0 2px; color:var(--t1);
}
.sc.go .sv { color:var(--cu); }
.sc.gr .sv { color:var(--p); }
.sc.ok .sv { color:var(--ok); }
.sc.bl .sv { color:var(--info); }

/* ── CARD ── */
.card {
  background: var(--card);
  border: 1.5px solid var(--bg3);
  border-radius: var(--rl);
  padding: 22px; margin-bottom:16px;
  box-shadow: var(--s1);
}
.ct {
  font-family: 'Cormorant Garamond', serif;
  font-size: 17px; font-weight: 700;
  margin-bottom: 18px; color: var(--t1);
  display: flex; align-items:center; gap:8px;
  letter-spacing: -.2px;
  padding-bottom: 12px;
  border-bottom: 1.5px solid var(--bg3);
}
.ct svg { width:16px; height:16px; color:var(--a); }
.g2 { display:grid; grid-template-columns:1fr 1fr; gap:16px; }

/* ── TABLE ── */
table { width:100%; border-collapse:collapse; font-size:13px; }
th {
  text-align:left; padding:8px 12px;
  font-size:10px; text-transform:uppercase;
  color:var(--t3); font-weight:700;
  border-bottom: 2px solid var(--bg3);
  letter-spacing:.8px;
  font-family: 'DM Mono', monospace;
}
td { padding:11px 12px; border-bottom:1px solid var(--edge2); color:var(--t2); font-size:13px; }
tr:last-child td { border-bottom:none; }
tr:hover td { background:var(--bg3); }

/* ── BADGES STATUTS ── */
.st {
  display:inline-flex; align-items:center; gap:5px;
  font-size:11px; font-weight:600;
  padding:3px 9px; border-radius:20px;
}
.st::before { content:''; width:5px; height:5px; border-radius:50%; }
.st.en_attente,.st.non_paye { background:var(--cubg); color:var(--cu); border:1.5px solid rgba(160,114,42,.2); }
.st.en_attente::before,.st.non_paye::before { background:var(--cu); }
.st.confirme,.st.en_preparation { background:var(--abg); color:var(--a); border:1.5px solid rgba(196,83,26,.2); }
.st.confirme::before,.st.en_preparation::before { background:var(--a); }
.st.pret,.st.en_livraison { background:var(--info-bg); color:var(--info); border:1.5px solid rgba(21,101,192,.2); }
.st.pret::before,.st.en_livraison::before { background:var(--info); }
.st.livre,.st.paye { background:var(--ok-bg); color:var(--ok); border:1.5px solid rgba(46,125,50,.2); }
.st.livre::before,.st.paye::before { background:var(--ok); }
.st.annule { background:var(--err-bg); color:var(--err); border:1.5px solid rgba(183,28,28,.2); }
.st.annule::before { background:var(--err); }

/* ── BOUTONS ── */
.btn {
  display:inline-flex; align-items:center; gap:6px;
  padding:8px 16px; border-radius:var(--r);
  font-size:13px; font-weight:600;
  cursor:pointer; border:none; transition:.15s;
  font-family:'Nunito',sans-serif;
}
.btn svg { width:15px; height:15px; }
.btn:disabled { opacity:.4; cursor:not-allowed; }
.btn-p {
  background: var(--p); color:#fff;
  box-shadow: 0 2px 10px rgba(45,74,45,.25);
}
.btn-p:hover:not(:disabled) { background:var(--p2); transform:translateY(-1px); box-shadow:0 4px 16px rgba(45,74,45,.3); }
.btn-amber {
  background: var(--cu); color:#fff;
  box-shadow: 0 2px 8px rgba(212,118,10,.25);
}
.btn-amber:hover:not(:disabled) { background:var(--cu2); transform:translateY(-1px); }
.btn-g {
  background:transparent; color:var(--t2);
  border:1px solid var(--edge);
}
.btn-g:hover { background:var(--bg3); color:var(--t1); }
.btn-ok   { background:var(--ok-bg); color:var(--ok); border:1px solid rgba(22,163,74,.2); }
.btn-warn { background:var(--warn-bg); color:var(--warn); border:1px solid rgba(217,119,6,.2); }
.btn-err  { background:var(--err-bg); color:var(--err); border:1px solid rgba(220,38,38,.2); }
.btn-sm   { padding:4px 10px; font-size:11.5px; }
.btn-full { width:100%; justify-content:center; padding:11px; }

/* ── FORMULAIRES ── */
.fg { margin-bottom:14px; }
.fl {
  display:block; font-size:11px; font-weight:700;
  color:var(--t3); margin-bottom:5px;
  text-transform:uppercase; letter-spacing:.7px;
  font-family:'DM Mono',monospace;
}
.fi, .fs {
  width:100%; background:var(--bg);
  border: 1.5px solid var(--edge);
  border-radius: 7px; padding:10px 14px;
  font-size:13.5px; color:var(--t1);
  font-family:'Nunito',sans-serif;
  outline:none; transition:.2s;
}
.fi:focus, .fs:focus {
  border-color: var(--p);
  background: var(--bg2);
  box-shadow: 0 0 0 3px rgba(45,74,45,.08);
}
textarea.fi { resize:vertical; min-height:72px; }
.fr { display:grid; grid-template-columns:1fr 1fr; gap:10px; }
.ferr {
  background:var(--err-bg); border:1.5px solid rgba(183,28,28,.2);
  color:var(--err); padding:10px 14px; border-radius:8px;
  font-size:13px; margin-bottom:10px; display:none;
  font-weight:600;
}
.ferr.show { display:block; }

/* ── PHOTO PROFIL ── */
.profil-card {
  display:flex; align-items:center; gap:18px;
  padding:18px; margin-bottom:16px;
  background:linear-gradient(135deg,var(--p3),var(--cubg));
  border-radius:var(--rl);
  border:1.5px solid rgba(45,74,45,.12);
}
.profil-ava-wrap { position:relative; cursor:pointer; flex-shrink:0; }
.profil-ava {
  width:80px; height:80px; border-radius:50%;
  background:linear-gradient(135deg,var(--p),#2d4a2d);
  display:flex; align-items:center; justify-content:center;
  font-family:'Cormorant Garamond',serif; font-size:28px; font-weight:700; color:#fff;
  overflow:hidden;
  border:3px solid #fff;
  box-shadow:var(--s2);
}
.profil-ava img { width:100%; height:100%; object-fit:cover; }
.profil-ava-overlay {
  position:absolute; inset:0; border-radius:50%;
  background:rgba(0,0,0,.55);
  display:flex; align-items:center; justify-content:center;
  opacity:0; transition:.2s; color:#fff;
}
.profil-ava-wrap:hover .profil-ava-overlay { opacity:1; }
.profil-ava-overlay svg { width:22px; height:22px; }
.profil-name { font-family:'Cormorant Garamond',serif; font-size:18px; font-weight:700; margin-bottom:2px; }
.profil-email { font-size:13px; color:var(--t3); }
.profil-actions { display:flex; gap:8px; margin-top:10px; }

/* ── MENU / CATALOGUE ── */
.cat-tabs { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:18px; }
.cat-tab {
  padding:6px 14px; border-radius:20px;
  border:1.5px solid var(--edge); background:#fff;
  color:var(--t2); cursor:pointer;
  font-size:12.5px; font-weight:600; transition:.15s;
  display:flex; align-items:center; gap:5px;
}
.cat-tab svg { width:13px; height:13px; }
.cat-tab:hover { border-color:var(--p); color:var(--p); }
.cat-tab.active { background:var(--p); color:#fff; border-color:var(--p); box-shadow:0 4px 12px rgba(45,74,45,.25); }

.menu-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:16px; }

.plat-card {
  background:var(--card); border:1.5px solid var(--bg3);
  border-radius:var(--rl); overflow:hidden;
  transition:all .2s ease; position:relative;
  box-shadow:var(--s1);
}
.plat-card:hover {
  border-color:var(--p);
  transform:translateY(-4px);
  box-shadow:var(--s3);
}
.plat-badge {
  position:absolute; top:10px; left:10px; z-index:1;
  background:linear-gradient(135deg,var(--cu),var(--cu2)); color:var(--bg);
  font-size:9.5px; font-weight:700; letter-spacing:.5px;
  padding:3px 9px; border-radius:20px;
  display:flex; align-items:center; gap:4px;
  box-shadow:0 2px 8px rgba(160,114,42,.35);
}
.plat-badge svg { width:10px; height:10px; }
.plat-img-wrap { position:relative; overflow:hidden; }
.plat-img { width:100%; height:148px; object-fit:cover; display:block; transition:.3s; }
.plat-card:hover .plat-img { transform:scale(1.04); }
.plat-img-ph {
  width:100%; height:148px;
  background:linear-gradient(135deg, var(--p3), var(--cubg));
  display:flex; flex-direction:column; align-items:center; justify-content:center;
  color:var(--t4); gap:6px;
}
.plat-img-ph svg { width:40px; height:40px; }
.plat-body { padding:14px; }
.plat-cat { font-size:9.5px; color:var(--p); text-transform:uppercase; letter-spacing:.8px; font-weight:700; margin-bottom:4px; font-family:'DM Mono',monospace; }
.plat-nom { font-family:'Cormorant Garamond',serif; font-size:17px; font-weight:700; margin-bottom:4px; color:var(--t1); line-height:1.2; }
.plat-desc { font-size:12px; color:var(--t3); line-height:1.4; margin-bottom:12px; height:32px; overflow:hidden; }
.plat-footer { display:flex; align-items:center; justify-content:space-between; }
.plat-prix { font-family:'Cormorant Garamond',serif; font-size:18px; font-weight:700; color:var(--a); letter-spacing:-.2px; }
.plat-time { font-size:11px; color:var(--t4); display:flex; align-items:center; gap:3px; }
.plat-time svg { width:11px; height:11px; }
.qty-row { display:flex; align-items:center; gap:6px; }
.qty-btn {
  width:28px; height:28px; border-radius:50%;
  background:var(--bg2); border:1.5px solid var(--edge);
  color:var(--t1); cursor:pointer; font-size:15px; font-weight:700;
  display:flex; align-items:center; justify-content:center; transition:.15s;
  line-height:1;
}
.qty-btn:hover { background:var(--p); border-color:var(--p); color:#fff; box-shadow:0 2px 8px rgba(45,74,45,.3); }
.qty-val { font-weight:700; font-size:14px; min-width:20px; text-align:center; color:var(--t1); }

/* ── PANIER FLOTTANT ── */
.panier-fixed { position:fixed; bottom:24px; right:24px; z-index:150; }
.panier-btn {
  background:linear-gradient(135deg,var(--p),var(--p2)); color:#fff; border:none;
  border-radius:30px; padding:12px 22px;
  font-size:13.5px; font-weight:700;
  cursor:pointer; display:flex; align-items:center; gap:9px;
  box-shadow:0 8px 24px rgba(45,74,45,.3);
  font-family:'Nunito',sans-serif; transition:.2s;
}
.panier-btn:hover { transform:translateY(-2px); box-shadow:0 12px 32px rgba(45,74,45,.35); }
.panier-btn svg { width:16px; height:16px; }
.panier-count {
  background:#fff; color:var(--cu);
  border-radius:50%; width:22px; height:22px;
  display:flex; align-items:center; justify-content:center;
  font-size:12px; font-weight:800;
}

/* ── MODALS ── */
.overlay {
  position:fixed; inset:0;
  background:rgba(28,20,8,.72);
  z-index:200; display:none;
  align-items:center; justify-content:center;
  backdrop-filter:blur(5px);
}
.overlay.open { display:flex; }
.modal {
  background: var(--bg2); border-radius: 16px;
  width:530px; max-height:88vh; overflow-y:auto; padding:28px;
  box-shadow:var(--s3); border:1.5px solid var(--bg3);
  animation:modalIn .25s cubic-bezier(.34,1.3,.64,1);
}
@keyframes modalIn {
  from { opacity:0; transform:scale(.96) translateY(8px); }
  to   { opacity:1; transform:scale(1) translateY(0); }
}
.modal-lg { width:660px; }
.mh { display:flex; align-items:center; justify-content:space-between; margin-bottom:18px; }
.mt { font-family:'Cormorant Garamond',serif; font-size:20px; font-weight:700; color:var(--t1); letter-spacing:-.3px; }
.mc {
  background:var(--bg3); border:none; color:var(--t3);
  width:30px; height:30px; border-radius:8px; cursor:pointer;
  display:flex; align-items:center; justify-content:center; transition:.15s;
}
.mc:hover { color:var(--err); background:var(--err-bg); }
.mc svg { width:14px; height:14px; }

/* ── PAIEMENT ── */
.pay-grid { display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-top:4px; }
.pay-opt {
  background:var(--bg3); border:2px solid var(--edge);
  border-radius:var(--r); padding:11px;
  cursor:pointer; text-align:center; transition:.15s;
}
.pay-opt:hover,.pay-opt.sel { border-color:var(--p); background:var(--p3); }
.pay-opt .pn { color:var(--t2) !important; }
.pay-opt .pn { font-size:12px; font-weight:600; margin-top:3px; color:var(--t1); }

.mode-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:8px; }
.mode-opt {
  background:var(--bg3); border:2px solid var(--edge);
  border-radius:var(--r); padding:10px;
  cursor:pointer; text-align:center; transition:.15s;
}
.mode-opt:hover,.mode-opt.sel { border-color:var(--a); background:var(--abg); }
.mode-opt .mn { font-size:12px; font-weight:600; margin-top:4px; }

.pay-instr {
  background:linear-gradient(135deg, var(--p3), var(--cubg));
  border:1.5px solid rgba(45,74,45,.1);
  border-radius:var(--r); padding:14px;
  font-size:13px; color:var(--t2); line-height:1.9;
  margin-bottom:14px; border:1px solid rgba(26,107,74,.1);
}
.pay-instr b { color:var(--t1); }

/* ── PANIER ITEMS ── */
.p-item {
  display:flex; align-items:center; justify-content:space-between;
  padding:10px 0; border-bottom:1px solid var(--edge2);
}
.p-item:last-child { border-bottom:none; }
.p-nom { font-weight:600; font-size:13px; }
.p-detail { font-size:11px; color:var(--t3); }
.p-prix { color:var(--cu); font-weight:700; }

/* ── CHAT ── */
.chat-box {
  height:300px; overflow-y:auto;
  padding:14px; display:flex; flex-direction:column; gap:8px;
  background:var(--bg); border-radius:var(--r);
  border:1.5px solid var(--bg3);
}
.cm { max-width:78%; }
.cm.admin { align-self:flex-end; }
.cb { padding:9px 13px; border-radius:12px; font-size:13px; line-height:1.5; }
.cm.client .cb { background:var(--bg2); border:1.5px solid var(--bg3); border-radius:4px 14px 14px 14px; }
.cm.admin  .cb { background:var(--p3); border:1.5px solid rgba(45,74,45,.15); border-radius:14px 4px 14px 14px; color:var(--p); font-weight:500; }
.cm-meta { font-size:10px; color:var(--t4); margin-top:2px; }
.cm.admin .cm-meta { text-align:right; }
.chat-row { display:flex; gap:8px; margin-top:10px; }
.chat-inp {
  flex:1; background:var(--bg3); border:1.5px solid var(--edge);
  border-radius:var(--r); padding:8px 12px;
  font-size:13px; color:var(--t1);
  font-family:'Nunito',sans-serif; outline:none;
}
.chat-inp:focus { border-color:var(--p); background:var(--bg2); }
.conv-item {
  display:flex; align-items:center; gap:10px;
  padding:10px; border-radius:var(--r);
  cursor:pointer; border-bottom:1px solid var(--edge2); transition:.15s;
}
.conv-item:hover { background:var(--p3); }

/* ── SWITCH ── */
.sw { position:relative; width:40px; height:21px; display:inline-block; }
.sw input { opacity:0; width:0; height:0; }
.sw-sl {
  position:absolute; cursor:pointer; inset:0;
  background:var(--t4); border-radius:21px; transition:.3s;
}
.sw-sl::before {
  content:''; position:absolute; width:15px; height:15px;
  background:#fff; border-radius:50%; bottom:3px; left:3px; transition:.3s;
  box-shadow:0 1px 3px rgba(0,0,0,.2);
}
input:checked+.sw-sl { background:var(--ok); }
input:checked+.sw-sl::before { transform:translateX(19px); }

/* ── IMAGE UPLOAD ── */
.img-upload {
  border:2px dashed var(--edge); border-radius:var(--r);
  padding:20px; text-align:center; cursor:pointer;
  transition:.2s; position:relative; overflow:hidden;
  background:var(--bg3);
}
.img-upload:hover { border-color:var(--p); background:var(--p3); }
.img-upload input[type=file] { position:absolute; inset:0; opacity:0; cursor:pointer; }
.img-prev { width:100%; height:150px; object-fit:cover; border-radius:8px; margin-top:8px; display:none; }
.img-prev.show { display:block; }
.img-ph { color:var(--t3); font-size:13px; }
.img-ph svg { width:32px; height:32px; display:block; margin:0 auto 8px; color:var(--p); opacity:.5; }

/* ── ADMIN MENU GRID ── */
.admin-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr)); gap:12px; }
.admin-plat {
  background:var(--bg2); border:1.5px solid var(--bg3);
  border-radius:var(--rl); overflow:hidden;
  box-shadow:var(--s1); transition:.2s;
}
.admin-plat:hover { border-color:var(--p); box-shadow:var(--s2); }
.admin-plat-img { width:100%; height:100px; object-fit:cover; }
.admin-plat-ph {
  width:100%; height:100px;
  background:var(--p3);
  display:flex; align-items:center; justify-content:center; color:var(--t4);
}
.admin-plat-ph svg { width:32px; height:32px; }
.admin-plat-body { padding:10px; }
.admin-plat-nom { font-weight:700; font-size:13px; margin-bottom:3px; color:var(--t1); font-family:'Cormorant Garamond',serif; font-size:15px; }
.admin-plat-prix { font-size:12px; color:var(--cu); font-weight:600; margin-bottom:8px; }
.admin-plat-foot { display:flex; align-items:center; justify-content:space-between; }

/* ── PROGRESS BAR ── */
.pbar { background:var(--bg3); border-radius:4px; height:5px; overflow:hidden; }
.pfill { height:100%; border-radius:4px; transition:width .6s; }
.pfill.go { background:linear-gradient(90deg,var(--cu),var(--cu2)); }
.pfill.gr { background:linear-gradient(90deg,var(--p),#2d9467); }
.pfill.ok { background:linear-gradient(90deg,var(--ok),#22c55e); }
.pfill.bl { background:linear-gradient(90deg,var(--info),#3b82f6); }

/* ── SPINNER ── */
.spin { display:inline-block; width:14px; height:14px; border:2px solid rgba(45,74,45,.2); border-top-color:var(--p); border-radius:50%; animation:sp .7s linear infinite; }
@keyframes sp { to{transform:rotate(360deg)} }
.loading { display:flex; align-items:center; justify-content:center; height:130px; gap:10px; color:var(--t3); font-size:13px; }

/* ── LOGIN ── */
.login-wrap {
  min-height:100vh; display:flex;
  align-items:center; justify-content:center; padding:20px;
  background:
    linear-gradient(160deg, #edf4ed 0%, #f7f2ea 40%, #fef3ea 100%);
  position:relative;
}
.login-wrap::before {
  content:'';
  position:absolute; inset:0; pointer-events:none;
  background:
    radial-gradient(circle at 15% 85%, rgba(45,74,45,.08) 0%, transparent 45%),
    radial-gradient(circle at 85% 15%, rgba(196,83,26,.06) 0%, transparent 45%);
}
.login-box {
  background:var(--bg2);
  border:1.5px solid var(--bg3);
  border-radius:18px; padding:40px; width:420px;
  box-shadow:0 20px 60px rgba(40,30,10,.14);
  position:relative; z-index:1;
}
.login-logo {
  display:flex; align-items:center; justify-content:center; gap:10px;
  margin-bottom:4px;
}
.login-logo-icon {
  width:44px; height:44px; border-radius:14px;
  background:linear-gradient(135deg,var(--p),var(--p2));
  display:flex; align-items:center; justify-content:center;
  box-shadow:0 4px 14px rgba(26,107,74,.3);
}
.login-logo-icon svg { color:#fff; width:22px; height:22px; }
.login-logo-text {
  font-family:'Cormorant Garamond',serif; font-size:26px; font-weight:700; color:var(--t1);
}
.login-logo-text em { color:var(--cu); font-style:normal; }
.login-tagline { text-align:center; color:var(--t3); font-size:12.5px; margin-bottom:26px; }

.tabs {
  display:flex; background:var(--bg3);
  border-radius:8px; padding:3px; margin-bottom:20px;
  border:1.5px solid var(--edge);
}
.tab {
  flex:1; text-align:center; padding:8px;
  border-radius:7px; font-size:13px; font-weight:700;
  cursor:pointer; color:var(--t3); transition:.15s;
}
.tab.active { background:var(--p); color:#fff; box-shadow:0 2px 8px rgba(45,74,45,.25); }

/* ── TOAST ── */
#toast {
  position:fixed; bottom:24px; right:24px;
  padding:13px 20px; border-radius:10px;
  font-size:13px; font-weight:700;
  z-index:999; display:none; max-width:340px;
  box-shadow:var(--s3);
  align-items:center; gap:9px;
  border-left:4px solid transparent;
}
#toast.show { display:flex; }
#toast svg { width:16px; height:16px; flex-shrink:0; }
#toast.s { background:#fff; color:var(--ok); border-color:var(--ok); box-shadow:var(--s2); }
#toast.e { background:#fff; color:var(--err); border-color:var(--err); box-shadow:var(--s2); }
#toast.i { background:#fff; color:var(--info); border-color:var(--info); box-shadow:var(--s2); }

::-webkit-scrollbar { width:5px; }
::-webkit-scrollbar-track { background:transparent; }
::-webkit-scrollbar-thumb { background:var(--bg3); border-radius:3px; border:1px solid var(--edge); }
::-webkit-scrollbar-track { background:transparent; }

@media(max-width:1000px){
  .sg{grid-template-columns:1fr 1fr;}
  .menu-grid{grid-template-columns:1fr 1fr;}
  .g2{grid-template-columns:1fr;}
  .sidebar{width:54px;padding:8px 6px;}
  .sidebar .ss,.sidebar .ni span,.sidebar .ni .nb{display:none;}
  .sidebar .ni{justify-content:center;}
  .sidebar .ni.active::before{display:none;}
}
@media(max-width:600px){
  .menu-grid,.sg{grid-template-columns:1fr 1fr;}
  .main{padding:14px;}
  .modal{width:calc(100vw - 20px);}
}

/* ── Micro-détails qui font la différence ── */

/* Sélect avec style */
select.fi, select.fs { appearance:none; background-image:url("data:image/svg+xml,%3Csvg width='10' height='6' viewBox='0 0 10 6' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%237a6a55'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 12px center; padding-right:32px; }

/* Lien discret */
a { color:var(--p); text-decoration:none; }
a:hover { text-decoration:underline; }

/* Focus visible accessible */
:focus-visible { outline:2px solid var(--p); outline-offset:2px; }

/* Image placeholder text */
.plat-img-ph span { font-size:11px; color:var(--t4); margin-top:4px; font-family:'DM Mono',monospace; }

/* Numéro commande style monospace */
.mono { font-family:'DM Mono',monospace; font-size:11px; color:var(--t3); letter-spacing:.5px; }

/* Bordure supérieure colorée pour les cards importantes */
.card-accent-top {
  border-top:3px solid var(--p) !important;
}

/* Prix montant */
.prix-highlight {
  font-family:'Cormorant Garamond',serif;
  font-size:22px; font-weight:700; color:var(--a);
}
</style>
</head>
<body>

<!-- ════ LOGIN ════ -->
<div id="loginWrap" class="login-wrap">
  <div class="login-box">
    <div class="login-logo">
      <div class="login-logo-icon"><svg data-lucide="utensils-crossed" width="22" height="22" style="color:#fff"></svg></div>
      <div class="login-logo-text">Calvin<em>Food</em></div>
    </div>
    <div class="login-tagline" style="font-style:italic;color:var(--t3)">Restaurant · Conakry 🇬🇳 · Cuisine africaine authentique</div>
    <div class="tabs">
      <div class="tab active" onclick="switchTab('login')">Connexion</div>
      <div class="tab" onclick="switchTab('signup')">Inscription</div>
    </div>
    <div class="ferr" id="authErr"></div>
    <div id="loginForm">
      <div class="fg"><label class="fl">Email</label><input class="fi" type="email" id="lEmail" placeholder="votre@email.com"></div>
      <div class="fg"><label class="fl">Mot de passe</label><input class="fi" type="password" id="lPass" placeholder="••••••••" onkeydown="if(event.key==='Enter')doLogin()"></div>
      <button class="btn btn-p btn-full" id="loginBtn" onclick="doLogin()"><span id="loginTxt">Se connecter</span></button>
      <div style="margin-top:14px;font-size:11px;color:var(--t4);text-align:center;line-height:2">
        Admin : admin@calvinfood.gn / <b style="color:var(--cu)">sidiki224</b><br>
        Client : client@gmail.com / <b style="color:var(--cu)">Client1234!</b>
      </div>
    </div>
    <div id="signupForm" style="display:none">
      <div class="fr">
        <div class="fg"><label class="fl">Nom complet</label><input class="fi" id="sNom" placeholder="Mamadou Kouyaté"></div>
        <div class="fg"><label class="fl">Téléphone</label><input class="fi" id="sTel" placeholder="+224 620..."></div>
      </div>
      <div class="fg"><label class="fl">Email</label><input class="fi" type="email" id="sEmail" placeholder="votre@email.com"></div>
      <div class="fg"><label class="fl">Mot de passe</label><input class="fi" type="password" id="sPass" placeholder="Min. 6 caractères"></div>
      <button class="btn btn-p btn-full" id="signupBtn" onclick="doSignup()"><span id="signupTxt">Créer mon compte</span></button>
    </div>
  </div>
</div>

<!-- ════ APP ════ -->
<div id="app" style="display:none">
  <div class="topbar">
    <div class="brand">
      <div class="brand-logo" style="background:var(--p)"><svg data-lucide="utensils-crossed" width="20" height="20" style="color:#fff"></svg></div>
      <div>
        <div class="brand-name">Calvin<em>Food</em></div>
        <div class="brand-sub">Conakry · Livraison &amp; Sur place</div>
      </div>
    </div>
    <div class="topbar-r">
      <span class="rbadge" id="rbadge">?</span>
      <div class="topbar-ava" id="topbarAva" onclick="goProfile()"><span id="topbarLetter">?</span></div>
      <button class="btn btn-g btn-sm" onclick="doLogout()">Déconnexion</button>
    </div>
  </div>

  <div class="layout">
    <!-- SIDEBAR ADMIN -->
    <div class="sidebar" id="sideAdmin" style="display:none">
      <div class="ss">Principal</div>
      <div class="ni active" onclick="nav('dashboard')"><span class="ic"><svg data-lucide="layout-dashboard"></svg></span><span>Dashboard</span></div>
      <div class="ni" onclick="nav('cmd-admin')"><span class="ic"><svg data-lucide="shopping-bag"></svg></span><span>Commandes</span><span class="nb" id="nbBadge">0</span></div>
      <div class="ni" onclick="nav('clients')"><span class="ic"><svg data-lucide="users"></svg></span><span>Clients</span></div>
      <div class="ss">Gestion</div>
      <div class="ni" onclick="nav('menu-admin')"><span class="ic"><svg data-lucide="chef-hat"></svg></span><span>Menu</span></div>
      <div class="ni" onclick="nav('finances')"><span class="ic"><svg data-lucide="wallet"></svg></span><span>Finances</span></div>
      <div class="ni" onclick="nav('msg-admin')"><span class="ic"><svg data-lucide="message-circle"></svg></span><span>Messages</span></div>
      <div class="ss">Compte</div>
      <div class="ni" onclick="nav('params')"><span class="ic"><svg data-lucide="settings"></svg></span><span>Paramètres</span></div>
    </div>
    <!-- SIDEBAR CLIENT -->
    <div class="sidebar" id="sideClt" style="display:none">
      <div class="ss">Navigation</div>
      <div class="ni active" onclick="nav('accueil')"><span class="ic"><svg data-lucide="home"></svg></span><span>Accueil</span></div>
      <div class="ni" onclick="nav('commander')"><span class="ic"><svg data-lucide="utensils"></svg></span><span>Commander</span></div>
      <div class="ni" onclick="nav('mes-cmd')"><span class="ic"><svg data-lucide="receipt"></svg></span><span>Mes commandes</span></div>
      <div class="ni" onclick="nav('msg-client')"><span class="ic"><svg data-lucide="message-circle"></svg></span><span>Messages</span></div>
      <div class="ss">Compte</div>
      <div class="ni" onclick="nav('mon-compte')"><span class="ic"><svg data-lucide="user-circle"></svg></span><span>Mon profil</span></div>
    </div>

    <div class="main">

      <!-- ADMIN DASHBOARD -->
      <div class="page" id="page-dashboard">
        <div class="ph"><div><div class="pt">Tableau de bord</div><div class="ps" id="dashSub">Vue d'ensemble de l'activité</div></div></div>
        <div class="sg">
          <div class="sc go"><div class="sc-icon"><svg data-lucide="trending-up"></svg></div><div class="sl">Revenus ce mois</div><div class="sv" id="dRev">—</div></div>
          <div class="sc gr"><div class="sc-icon"><svg data-lucide="shopping-bag"></svg></div><div class="sl">Commandes actives</div><div class="sv" id="dAct">—</div></div>
          <div class="sc ok"><div class="sc-icon"><svg data-lucide="users"></svg></div><div class="sl">Clients</div><div class="sv" id="dCli">—</div></div>
          <div class="sc bl"><div class="sc-icon"><svg data-lucide="bike"></svg></div><div class="sl">Livraisons today</div><div class="sv" id="dLiv">—</div></div>
        </div>
        <div class="g2">
          <div class="card"><div class="ct"><svg data-lucide="clock"></svg>Dernières commandes</div><div id="dashOrders"><div class="loading"><div class="spin"></div></div></div></div>
          <div class="card"><div class="ct"><svg data-lucide="star"></svg>Plats populaires</div><div id="dashPop"><div class="loading"><div class="spin"></div></div></div></div>
        </div>
      </div>

      <!-- ADMIN COMMANDES -->
      <div class="page" id="page-cmd-admin">
        <div class="ph"><div><div class="pt">Commandes</div><div class="ps">Gérer toutes les commandes</div></div></div>
        <div class="card"><div id="ordersTable"><div class="loading"><div class="spin"></div></div></div></div>
      </div>

      <!-- ADMIN CLIENTS -->
      <div class="page" id="page-clients">
        <div class="ph"><div><div class="pt">Clients</div><div class="ps" id="cliCount">—</div></div></div>
        <div class="card"><div id="clientsTable"><div class="loading"><div class="spin"></div></div></div></div>
      </div>

      <!-- ADMIN MENU -->
      <div class="page" id="page-menu-admin">
        <div class="ph">
          <div><div class="pt">Gestion du Menu</div><div class="ps">Ajoutez vos plats avec photos</div></div>
          <button class="btn btn-p" onclick="openM('mNewPlat')"><svg data-lucide="plus"></svg>Ajouter un plat</button>
        </div>
        <div id="adminMenuCats"></div>
      </div>

      <!-- ADMIN FINANCES -->
      <div class="page" id="page-finances">
        <div class="ph"><div><div class="pt">Finances</div></div></div>
        <div class="sg">
          <div class="sc ok"><div class="sc-icon"><svg data-lucide="banknote"></svg></div><div class="sl">Revenus mois</div><div class="sv" id="fRev">—</div></div>
          <div class="sc go"><div class="sc-icon"><svg data-lucide="clock"></svg></div><div class="sl">En attente</div><div class="sv" id="fAtt">—</div></div>
          <div class="sc bl"><div class="sc-icon"><svg data-lucide="receipt"></svg></div><div class="sl">Total commandes</div><div class="sv" id="fTot">—</div></div>
          <div class="sc gr"><div class="sc-icon"><svg data-lucide="users"></svg></div><div class="sl">Clients</div><div class="sv" id="fCli">—</div></div>
        </div>
        <div class="card"><div class="ct"><svg data-lucide="list"></svg>Toutes les transactions</div><div id="finTable"><div class="loading"><div class="spin"></div></div></div></div>
      </div>

      <!-- ADMIN MESSAGES -->
      <div class="page" id="page-msg-admin">
        <div class="ph"><div><div class="pt">Messages</div></div></div>
        <div class="g2">
          <div class="card"><div class="ct"><svg data-lucide="inbox"></svg>Conversations</div><div id="convList"><div class="loading"><div class="spin"></div></div></div></div>
          <div class="card">
            <div class="ct"><svg data-lucide="message-circle"></svg><span id="chatNomWrap">—</span></div>
            <div class="chat-box" id="adminChatBox"><div style="text-align:center;color:var(--t4);font-size:13px;padding:30px">Sélectionner une conversation</div></div>
            <div class="chat-row">
              <input class="chat-inp" id="adminChatInp" placeholder="Écrire un message..." onkeydown="if(event.key==='Enter')sendAdminMsg()">
              <button class="btn btn-p btn-sm" onclick="sendAdminMsg()"><svg data-lucide="send"></svg></button>
            </div>
          </div>
        </div>
      </div>

      <!-- ADMIN PARAMÈTRES -->
      <div class="page" id="page-params">
        <div class="ph"><div><div class="pt">Paramètres</div></div></div>
        <div class="profil-card" id="adminProfilCard">
          <div class="profil-ava-wrap" onclick="document.getElementById('adminPhotoInput').click()">
            <div class="profil-ava" id="adminProfilAva"><span id="adminProfilLetter">A</span></div>
            <div class="profil-ava-overlay"><svg data-lucide="camera"></svg></div>
            <input type="file" id="adminPhotoInput" accept="image/*" style="display:none" onchange="uploadPhoto(this)">
          </div>
          <div>
            <div class="profil-name" id="adminProfilName">—</div>
            <div class="profil-email" id="adminProfilEmail">—</div>
            <div class="profil-actions">
              <button class="btn btn-g btn-sm" onclick="document.getElementById('adminPhotoInput').click()"><svg data-lucide="camera"></svg>Changer la photo</button>
              <button class="btn btn-err btn-sm" onclick="supprimerPhoto()"><svg data-lucide="trash-2"></svg>Supprimer</button>
            </div>
          </div>
        </div>
        <div class="g2">
          <div class="card">
            <div class="ct"><svg data-lucide="user"></svg>Mes informations</div>
            <div class="fg"><label class="fl">Nom complet</label><input class="fi" id="pNom"></div>
            <div class="fg"><label class="fl">Email</label><input class="fi" id="pEmail" readonly style="opacity:.5"></div>
            <div class="fg"><label class="fl">Téléphone</label><input class="fi" id="pTel"></div>
            <button class="btn btn-p" onclick="saveProfile()"><svg data-lucide="save"></svg>Enregistrer</button>
          </div>
          <div class="card">
            <div class="ct"><svg data-lucide="lock"></svg>Sécurité</div>
            <div class="fg"><label class="fl">Mot de passe actuel</label><input type="password" class="fi" id="pCur"></div>
            <div class="fg"><label class="fl">Nouveau mot de passe</label><input type="password" class="fi" id="pNew"></div>
            <div class="fg"><label class="fl">Confirmer</label><input type="password" class="fi" id="pConf"></div>
            <button class="btn btn-g" onclick="changePass('pCur','pNew','pConf')"><svg data-lucide="shield"></svg>Modifier</button>
          </div>
        </div>
      </div>

      <!-- CLIENT ACCUEIL -->
      <div class="page" id="page-accueil">
        <div class="ph"><div><div class="pt">Bienvenue chez CalvinFood</div><div class="ps" id="cWelcome">—</div></div></div>
        <div class="sg">
          <div class="sc bl"><div class="sc-icon"><svg data-lucide="shopping-bag"></svg></div><div class="sl">Mes commandes</div><div class="sv" id="csTot">—</div></div>
          <div class="sc ok"><div class="sc-icon"><svg data-lucide="check-circle"></svg></div><div class="sl">Livrées</div><div class="sv" id="csDone">—</div></div>
          <div class="sc go"><div class="sc-icon"><svg data-lucide="loader"></svg></div><div class="sl">En cours</div><div class="sv" id="csAct">—</div></div>
          <div class="sc gr"><div class="sc-icon"><svg data-lucide="wallet"></svg></div><div class="sl">Total dépensé</div><div class="sv" id="csAmt">—</div></div>
        </div>
        <!-- CTA commander -->
        <div style="background:linear-gradient(135deg,var(--abg),var(--cubg));border:1.5px solid rgba(196,83,26,.15);border-radius:var(--rl);padding:20px 24px;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
          <div>
            <div style="font-family:'Cormorant Garamond',serif;font-size:18px;font-weight:700;color:var(--t1)">Envie de quelque chose ?</div>
            <div style="font-size:13px;color:var(--t3);margin-top:2px">Découvrez nos plats préparés avec des ingrédients frais</div>
          </div>
          <button class="btn btn-p" onclick="nav('commander')"><svg data-lucide="utensils"></svg>Voir le menu</button>
        </div>
        <div class="card"><div class="ct"><svg data-lucide="clock"></svg>Mes dernières commandes</div><div id="cHomeOrders"><div class="loading"><div class="spin"></div></div></div></div>
      </div>

      <!-- CLIENT COMMANDER -->
      <div class="page" id="page-commander">
        <div style="background:linear-gradient(135deg,var(--p),var(--p2));border-radius:var(--rl);padding:24px 28px;margin-bottom:22px;position:relative;overflow:hidden;">
          <div style="position:absolute;right:20px;top:50%;transform:translateY(-50%);font-size:72px;opacity:.12;line-height:1">🍽</div>
          <div style="font-family:'Cormorant Garamond',serif;font-size:26px;font-weight:700;color:#fff;margin-bottom:6px;letter-spacing:-.4px">Notre Menu du Jour</div>
          <div style="font-size:13px;color:rgba(255,255,255,.7);font-style:italic">Cuisinés avec passion · Frais chaque jour · Conakry 🇬🇳</div>
        </div>
        <div id="catTabs" class="cat-tabs"></div>
        <div id="menuGrid" class="menu-grid"><div class="loading" style="grid-column:1/-1"><div class="spin"></div></div></div>
      </div>

      <!-- CLIENT MES COMMANDES -->
      <div class="page" id="page-mes-cmd">
        <div class="ph"><div><div class="pt">Mes Commandes</div></div></div>
        <div class="card"><div id="myOrders"><div class="loading"><div class="spin"></div></div></div></div>
      </div>

      <!-- CLIENT MESSAGES -->
      <div class="page" id="page-msg-client">
        <div class="ph"><div><div class="pt">Messages</div></div></div>
        <div class="g2">
          <div class="card"><div class="ct"><svg data-lucide="list"></svg>Mes commandes</div><div id="myConvList"><div class="loading"><div class="spin"></div></div></div></div>
          <div class="card">
            <div class="ct"><svg data-lucide="message-circle"></svg><span id="cChatTitle">Sélectionner</span></div>
            <div class="chat-box" id="clientChatBox"><div style="text-align:center;color:var(--t4);font-size:13px;padding:30px">Sélectionnez une commande</div></div>
            <div class="chat-row">
              <input class="chat-inp" id="cChatInp" placeholder="Votre message..." onkeydown="if(event.key==='Enter')sendClientMsg()">
              <button class="btn btn-p btn-sm" onclick="sendClientMsg()"><svg data-lucide="send"></svg></button>
            </div>
          </div>
        </div>
      </div>

      <!-- CLIENT MON PROFIL -->
      <div class="page" id="page-mon-compte">
        <div class="ph"><div><div class="pt">Mon Profil</div></div></div>
        <div class="profil-card">
          <div class="profil-ava-wrap" onclick="document.getElementById('clientPhotoInput').click()">
            <div class="profil-ava" id="clientProfilAva"><span id="clientProfilLetter">C</span></div>
            <div class="profil-ava-overlay"><svg data-lucide="camera"></svg></div>
            <input type="file" id="clientPhotoInput" accept="image/*" style="display:none" onchange="uploadPhoto(this)">
          </div>
          <div>
            <div class="profil-name" id="clientProfilName">—</div>
            <div class="profil-email" id="clientProfilEmail">—</div>
            <div class="profil-actions">
              <button class="btn btn-g btn-sm" onclick="document.getElementById('clientPhotoInput').click()"><svg data-lucide="camera"></svg>Changer la photo</button>
              <button class="btn btn-err btn-sm" onclick="supprimerPhoto()"><svg data-lucide="trash-2"></svg>Supprimer</button>
            </div>
          </div>
        </div>
        <div class="g2">
          <div class="card">
            <div class="ct"><svg data-lucide="user"></svg>Mes informations</div>
            <div class="fg"><label class="fl">Nom complet</label><input class="fi" id="cNom"></div>
            <div class="fg"><label class="fl">Email</label><input class="fi" id="cEmail" readonly style="opacity:.5"></div>
            <div class="fg"><label class="fl">Téléphone</label><input class="fi" id="cTel"></div>
            <div class="fg"><label class="fl">Quartier</label><input class="fi" id="cQuartier" placeholder="Kaloum, Conakry"></div>
            <button class="btn btn-p" onclick="saveClientProfile()"><svg data-lucide="save"></svg>Enregistrer</button>
          </div>
          <div class="card">
            <div class="ct"><svg data-lucide="lock"></svg>Sécurité</div>
            <div class="fg"><label class="fl">Mot de passe actuel</label><input type="password" class="fi" id="cpCur"></div>
            <div class="fg"><label class="fl">Nouveau mot de passe</label><input type="password" class="fi" id="cpNew"></div>
            <div class="fg"><label class="fl">Confirmer</label><input type="password" class="fi" id="cpConf"></div>
            <button class="btn btn-g" onclick="changePass('cpCur','cpNew','cpConf')"><svg data-lucide="shield"></svg>Modifier</button>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

<!-- Panier flottant -->
<div class="panier-fixed" id="panierFixed" style="display:none">
  <button class="panier-btn" onclick="openPanier()">
    <svg data-lucide="shopping-cart"></svg> Mon panier
    <span class="panier-count" id="panierCount">0</span>
    <span id="panierTotalBtn" style="font-size:12px;opacity:.85"></span>
  </button>
</div>

<!-- ════ MODALS ════ -->

<!-- PANIER -->
<div class="overlay" id="mPanier">
  <div class="modal modal-lg">
    <div class="mh"><div class="mt">Mon Panier</div><button class="mc" onclick="closeM('mPanier')"><svg data-lucide="x"></svg></button></div>
    <div id="panierItems"></div>
    <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-top:2px solid var(--edge2);margin:10px 0 16px">
      <span style="font-weight:700;color:var(--t2);font-size:12px;text-transform:uppercase;letter-spacing:.5px">Total à payer</span>
      <span style="font-family:'Cormorant Garamond',serif;font-size:24px;font-weight:700;color:var(--cu)" id="panierTotalModal">0 GNF</span>
    </div>
    <div class="fg">
      <label class="fl">Mode de service</label>
      <div class="mode-grid">
        <div class="mode-opt sel" onclick="selMode(this,'sur_place')"><div style="font-size:22px">🪑</div><div class="mn">Sur place</div></div>
        <div class="mode-opt" onclick="selMode(this,'livraison')"><div style="font-size:22px">🛵</div><div class="mn">Livraison</div></div>
        <div class="mode-opt" onclick="selMode(this,'emporter')"><div style="font-size:22px">🥡</div><div class="mn">À emporter</div></div>
      </div>
      <input type="hidden" id="cmdMode" value="sur_place">
    </div>
    <div id="adresseGroup" style="display:none">
      <div class="fg"><label class="fl">Adresse de livraison</label><input class="fi" id="cmdAdresse" placeholder="Quartier, rue, point de repère..."></div>
      <div class="fg"><label class="fl">Téléphone livraison</label><input class="fi" id="cmdTel" placeholder="+224 620..."></div>
    </div>
    <div class="fg">
      <label class="fl">Méthode de paiement</label>
      <div class="pay-grid">
        <div class="pay-opt sel" onclick="selPay(this,'especes')"><div style="font-size:20px">💵</div><div class="pn">Espèces</div></div>
        <div class="pay-opt" onclick="selPay(this,'orange_money')"><div style="font-size:20px">📱</div><div class="pn" style="color:#ff6600">Orange Money</div></div>
        <div class="pay-opt" onclick="selPay(this,'mtn_momo')"><div style="font-size:20px">📱</div><div class="pn" style="color:#ffc107">MTN MoMo</div></div>
        <div class="pay-opt" onclick="selPay(this,'virement')"><div style="font-size:20px">🏦</div><div class="pn">Virement</div></div>
      </div>
      <input type="hidden" id="cmdPay" value="especes">
    </div>
    <div class="fg"><label class="fl">Notes (optionnel)</label><textarea class="fi" id="cmdNotes" placeholder="Allergies, préférences..."></textarea></div>
    <button class="btn btn-p btn-full" id="cmdBtn" onclick="passerCommande()"><span id="cmdBtnTxt"><svg data-lucide="check"></svg>Confirmer la commande</span></button>
  </div>
</div>

<!-- PAIEMENT -->
<div class="overlay" id="mPay">
  <div class="modal">
    <div class="mh"><div class="mt" id="payTitle">Paiement</div><button class="mc" onclick="closeM('mPay')"><svg data-lucide="x"></svg></button></div>
    <div style="text-align:center;padding:16px 0">
      <div style="font-size:44px" id="payEmoji">💵</div>
      <div style="font-family:'Cormorant Garamond',serif;font-size:28px;font-weight:700;color:var(--cu);margin:10px 0" id="payMontant">—</div>
      <div style="font-size:12px;color:var(--t3)">GNF à régler</div>
    </div>
    <div class="pay-instr" id="payInstr"></div>
    <div class="fg"><label class="fl">Référence de transaction</label><input class="fi" id="payRef" placeholder="ex: OM20250101000001"></div>
    <button class="btn btn-p btn-full" onclick="soumettrePaiement()"><svg data-lucide="check-circle"></svg>J'ai effectué le paiement</button>
    <div style="font-size:11px;color:var(--t4);text-align:center;margin-top:8px">Validé après vérification par l'équipe Calvin Food</div>
  </div>
</div>

<!-- NOUVEAU PLAT -->
<div class="overlay" id="mNewPlat">
  <div class="modal">
    <div class="mh"><div class="mt">Ajouter un plat</div><button class="mc" onclick="closeM('mNewPlat')"><svg data-lucide="x"></svg></button></div>
    <div class="fg">
      <label class="fl">Photo du plat</label>
      <div class="img-upload" onclick="document.getElementById('imgInput').click()">
        <input type="file" id="imgInput" accept="image/*,image/heic,image/heif,image/avif" onchange="previewImg(this,'imgPrev','imgPh')">
        <div id="imgPh"><svg data-lucide="image-plus"></svg>Cliquer pour ajouter une photo<br><span style="font-size:11px;color:var(--t4)">JPG, PNG, WEBP, HEIC · Max 10MB</span></div>
        <img id="imgPrev" class="img-prev" src="" alt="">
      </div>
    </div>
    <div class="fr">
      <div class="fg"><label class="fl">Nom du plat *</label><input class="fi" id="npNom" placeholder="Poulet braisé..."></div>
      <div class="fg"><label class="fl">Prix (GNF) *</label><input class="fi" type="number" id="npPrix"></div>
    </div>
    <div class="fg"><label class="fl">Catégorie</label><select class="fs" id="npCat"></select></div>
    <div class="fg"><label class="fl">Description</label><textarea class="fi" id="npDesc" placeholder="Décrivez ce plat..."></textarea></div>
    <div class="fr">
      <div class="fg"><label class="fl">Temps prep (min)</label><input class="fi" type="number" id="npTemps" value="20"></div>
      <div class="fg"><label class="fl">Code</label><input class="fi" id="npIcone" placeholder="PA/GR/PO..."></div>
    </div>
    <div class="fg" style="display:flex;align-items:center;gap:10px">
      <label class="sw"><input type="checkbox" id="npPop"><span class="sw-sl"></span></label>
      <span style="font-size:13px;color:var(--t2)">Marquer comme plat populaire ⭐</span>
    </div>
    <button class="btn btn-p btn-full" id="savePlatBtn" style="margin-top:6px" onclick="createPlat()">
      <span id="savePlatTxt"><svg data-lucide="plus-circle"></svg>Ajouter au menu</span>
    </button>
  </div>
</div>

<!-- MODIFIER PLAT -->
<div class="overlay" id="mEditPlat">
  <div class="modal">
    <div class="mh"><div class="mt">Modifier le plat</div><button class="mc" onclick="closeM('mEditPlat')"><svg data-lucide="x"></svg></button></div>
    <input type="hidden" id="epId"><input type="hidden" id="epImgActuelle">
    <div class="fg">
      <label class="fl">Photo</label>
      <div class="img-upload" onclick="document.getElementById('epImgInput').click()">
        <input type="file" id="epImgInput" accept="image/*,image/heic,image/heif,image/avif" onchange="previewImg(this,'epImgPrev',null)">
        <img id="epImgPrev" class="img-prev" src="" alt="">
        <div style="font-size:12px;color:var(--t3);margin-top:6px">Cliquer pour changer la photo</div>
      </div>
    </div>
    <div class="fr">
      <div class="fg"><label class="fl">Nom *</label><input class="fi" id="epNom"></div>
      <div class="fg"><label class="fl">Prix (GNF) *</label><input class="fi" type="number" id="epPrix"></div>
    </div>
    <div class="fg"><label class="fl">Catégorie</label><select class="fs" id="epCat"></select></div>
    <div class="fg"><label class="fl">Description</label><textarea class="fi" id="epDesc"></textarea></div>
    <div class="fr">
      <div class="fg"><label class="fl">Temps prep (min)</label><input class="fi" type="number" id="epTemps"></div>
      <div class="fg"><label class="fl">Code</label><input class="fi" id="epIcone"></div>
    </div>
    <div style="display:flex;gap:20px;margin-bottom:14px">
      <div style="display:flex;align-items:center;gap:8px"><label class="sw"><input type="checkbox" id="epPop"><span class="sw-sl"></span></label><span style="font-size:13px;color:var(--t2)">Populaire ⭐</span></div>
      <div style="display:flex;align-items:center;gap:8px"><label class="sw"><input type="checkbox" id="epDispo"><span class="sw-sl"></span></label><span style="font-size:13px;color:var(--t2)">Disponible</span></div>
    </div>
    <button class="btn btn-p btn-full" id="editPlatBtn" onclick="savePlatEdit()">
      <span id="editPlatTxt"><svg data-lucide="save"></svg>Enregistrer</span>
    </button>
  </div>
</div>

<div id="toast"><span id="toastIcon"></span><span id="toastMsg"></span></div>

<script>
const PHP = 'index.php?ajax=1';
const S_LBL = {en_attente:'En attente',confirme:'Confirmé',en_preparation:'En préparation',pret:'Prêt',en_livraison:'En livraison',livre:'Livré',annule:'Annulé'};
const PAY_INFO = {
  orange_money:{
    titre:'Orange Money', emoji:'📱',
    instr:`<div style="text-align:center;margin-bottom:12px">
      <div style="font-size:13px;color:var(--t3)">Numéro Orange Money</div>
      <div style="font-family:'Cormorant Garamond',serif;font-size:26px;font-weight:700;color:#ff6600;margin:6px 0">+224 628 37 32 35</div>
    </div>
    <b>Étapes :</b><br>
    1. Composez <b>*144#</b> sur votre Orange<br>
    2. Choisissez <b>Transfert d'argent</b><br>
    3. Numéro destinataire : <b style="color:#ff6600">628 37 32 35</b><br>
    4. Entrez le montant exact et confirmez avec votre PIN<br>
    5. Notez la référence SMS reçue`
  },
  mtn_momo:{titre:'MTN MoMo',emoji:'📱',instr:`Composez <b>*165*1#</b> → Envoyer de l'argent → <b style="color:#ffc107">+224 622 XX XX XX</b><br>Montant exact → PIN → Notez la référence SMS`},
  especes:{titre:'Paiement Espèces',emoji:'💵',instr:`Payez directement au comptoir ou remettez les espèces au livreur. Aucune action supplémentaire requise.`},
  virement:{titre:'Virement Bancaire',emoji:'🏦',instr:`Banque : <b>BICIGUI</b> — Titulaire : <b>Calvin Food SARL</b><br>Motif : votre numéro de commande`},
};

let user=null, panier={}, chatCid=null, payOrderId=null, menuData=[], catsData=[];

// ── Fetch ──────────────────────────────────────────
async function post(data){
  const fd=new FormData(); Object.entries(data).forEach(([k,v])=>{if(v!=null)fd.append(k,v)});
  try{const r=await fetch(PHP,{method:'POST',body:fd});return await r.json();}
  catch(e){return{success:false,message:'Erreur réseau. WampServer démarré ?'};}
}
async function get(p){
  const qs=new URLSearchParams(p).toString();
  try{const r=await fetch(PHP+'&'+qs);return await r.json();}
  catch(e){return{success:false};}
}

// ── Auth ──────────────────────────────────────────
function switchTab(t){
  document.querySelectorAll('.tab').forEach((el,i)=>el.classList.toggle('active',(t==='login'&&i===0)||(t==='signup'&&i===1)));
  document.getElementById('loginForm').style.display=t==='login'?'block':'none';
  document.getElementById('signupForm').style.display=t==='signup'?'block':'none';
  showAuthErr('');
}
async function doLogin(){
  const email=document.getElementById('lEmail').value.trim();
  const pass=document.getElementById('lPass').value;
  if(!email||!pass){showAuthErr('Email et mot de passe requis.');return;}
  btnLoad('loginBtn','loginTxt','Connexion...');
  const r=await post({action:'login',email,password:pass});
  btnLoad('loginBtn','loginTxt','Se connecter',false);
  if(!r.success){showAuthErr(r.message);return;}
  startApp(r.data);
}
async function doSignup(){
  const nom=document.getElementById('sNom').value.trim();
  const tel=document.getElementById('sTel').value.trim();
  const email=document.getElementById('sEmail').value.trim();
  const pass=document.getElementById('sPass').value;
  if(!nom||!email||!pass){showAuthErr('Champs obligatoires manquants.');return;}
  if(pass.length<6){showAuthErr('Mot de passe minimum 6 caractères.');return;}
  btnLoad('signupBtn','signupTxt','Création...');
  const r=await post({action:'register',nom,telephone:tel,email,password:pass});
  btnLoad('signupBtn','signupTxt','Créer mon compte',false);
  if(!r.success){showAuthErr(r.message);return;}
  startApp(r.data);
}
async function doLogout(){
  await post({action:'logout'}); user=null; panier={};
  document.getElementById('app').style.display='none';
  document.getElementById('loginWrap').style.display='flex';
  document.getElementById('panierFixed').style.display='none';
}
function showAuthErr(msg){const el=document.getElementById('authErr');el.textContent=msg?'⚠ '+msg:'';el.classList.toggle('show',!!msg);}

// ── Init App ──────────────────────────────────────
function startApp(u){
  user=u;
  document.getElementById('loginWrap').style.display='none';
  document.getElementById('app').style.display='block';
  const isAdm=u.role==='admin';
  document.getElementById('rbadge').textContent=isAdm?'Admin':'Client';
  document.getElementById('rbadge').className='rbadge '+(isAdm?'admin':'client');
  setTopbarAva(u.nom,u.photo||'');
  document.getElementById('sideAdmin').style.display=isAdm?'flex':'none';
  setTimeout(()=>lucide.createIcons(),50);
  document.getElementById('sideClt').style.display=isAdm?'none':'flex';
  if(isAdm){document.getElementById('dashSub').textContent='Bienvenue, '+u.nom;loadDashboard();nav('dashboard');}
  else{
    document.getElementById('cWelcome').textContent='Bonjour '+u.nom+' — Que désirez-vous aujourd\'hui ?';
    document.getElementById('cNom').value=u.nom||'';
    document.getElementById('cEmail').value=u.email||'';
    document.getElementById('cTel').value=u.telephone||'';
    loadClientHome(); nav('accueil');
  }
  lucide.createIcons();
}
function setTopbarAva(nom,photo){
  const w=document.getElementById('topbarAva');
  if(photo){w.innerHTML=`<img src="${h(photo)}" alt="profil">`;}
  else{w.innerHTML=`<span id="topbarLetter">${(nom||'?').charAt(0).toUpperCase()}</span>`;}
}
function goProfile(){if(!user)return; nav(user.role==='admin'?'params':'mon-compte');}
(async()=>{const r=await get({action:'session'});if(r.success&&r.data)startApp(r.data);})();

// ── Navigation ────────────────────────────────────
function nav(page){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  const el=document.getElementById('page-'+page); if(el){el.classList.add('active');}
  document.querySelectorAll('.ni').forEach(n=>n.classList.toggle('active',(n.getAttribute('onclick')||'').includes("'"+page+"'")));
  const loads={'cmd-admin':loadAdminOrders,'clients':loadClients,'menu-admin':loadAdminMenu,
    'finances':loadFinances,'msg-admin':loadConversations,'commander':loadMenu,
    'mes-cmd':loadMyOrders,'msg-client':loadMyConvList,'params':loadParamProfile,'mon-compte':loadClientProfile};
  if(loads[page])loads[page]();
}

// ── Photo profil ──────────────────────────────────
async function uploadPhoto(input){
  if(!input.files[0])return;
  const fd=new FormData(); fd.append('action','upload_photo_profil'); fd.append('photo',input.files[0]);
  toast('Envoi de la photo...','i');
  try{
    const res=await fetch(PHP,{method:'POST',body:fd}); const r=await res.json();
    if(!r.success){toast(r.message,'e');return;}
    toast(r.message,'s');
    user.photo=r.data.photo;
    setTopbarAva(user.nom,r.data.photo);
    updateProfilUI(r.data.photo);
  }catch(e){toast('Erreur upload.','e');}
}
async function supprimerPhoto(){
  if(!confirm('Supprimer la photo de profil ?'))return;
  const r=await post({action:'supprimer_photo'});
  toast(r.message,r.success?'s':'e');
  if(r.success){user.photo='';setTopbarAva(user.nom,'');updateProfilUI('');}
}
function updateProfilUI(photo){
  const nom=user?.nom||'?';
  ['adminProfilAva','clientProfilAva'].forEach(id=>{
    const el=document.getElementById(id); if(!el)return;
    if(photo){el.innerHTML=`<img src="${h(photo)}" alt="profil">`;}
    else{el.innerHTML=`<span>${nom.charAt(0).toUpperCase()}</span>`;}
  });
}

// ── Admin Dashboard ───────────────────────────────
async function loadDashboard(){
  const [stats,recents,menu]=await Promise.all([get({action:'commandes_stats'}),get({action:'commandes_list'}),get({action:'menu_admin'})]);
  if(stats.data){
    document.getElementById('dRev').textContent=stats.data.revenu_mois;
    document.getElementById('dAct').textContent=stats.data.actives;
    document.getElementById('dCli').textContent=stats.data.clients;
    document.getElementById('dLiv').textContent=stats.data.livraisons_jour;
    document.getElementById('nbBadge').textContent=stats.data.en_attente;
  }
  document.getElementById('dashOrders').innerHTML=recents.data?.length
    ?`<table><thead><tr><th>Numéro</th><th>Client</th><th>Plats</th><th>Montant</th><th>Statut</th></tr></thead><tbody>
    ${recents.data.slice(0,6).map(o=>`<tr>
      <td style="color:var(--t4);font-size:11px">${h(o.numero_commande)}</td>
      <td><div style="display:flex;align-items:center;gap:7px">
        ${o.photo_client?`<img src="${h(o.photo_client)}" style="width:26px;height:26px;border-radius:50%;object-fit:cover;border:2px solid var(--edge)">`:`<div style="width:26px;height:26px;border-radius:50%;background:var(--p);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:#fff">${(o.nom_complet||'?').charAt(0)}</div>`}
        ${h(o.nom_complet||'—')}
      </div></td>
      <td style="font-size:11px;max-width:140px">${h(o.resume_plats||'—')}</td>
      <td style="color:var(--cu);font-weight:600">${o.montant_formate}</td>
      <td><span class="st ${o.statut}">${S_LBL[o.statut]||o.statut}</span></td>
    </tr>`).join('')}</tbody></table>`
    :empty('Aucune commande pour le moment');
  const pop=(menu.data||[]).filter(p=>p.est_populaire=='1').slice(0,5);
  document.getElementById('dashPop').innerHTML=pop.length
    ?pop.map((p,i)=>{const pct=100-i*17;const cls=['go','gr','ok','bl','go'][i%5]; return`
    <div style="margin-bottom:12px">
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:5px">
        <span>${h(p.nom)}</span><span style="color:var(--cu);font-weight:600">${h(p.prix_formate)}</span>
      </div>
      <div class="pbar"><div class="pfill ${cls}" style="width:${pct}%"></div></div>
    </div>`;}).join('')
    :empty('Marquez des plats comme populaires');
  lucide.createIcons();
}

// ── Admin Commandes ───────────────────────────────
async function loadAdminOrders(){
  document.getElementById('ordersTable').innerHTML=loading();
  const r=await get({action:'commandes_list'});
  if(!r.data?.length){document.getElementById('ordersTable').innerHTML=empty('Aucune commande');return;}
  const opts=['en_attente','confirme','en_preparation','pret','en_livraison','livre','annule'];
  document.getElementById('ordersTable').innerHTML=`<table>
    <thead><tr><th>#</th><th>Client</th><th>Plats</th><th>Mode</th><th>Montant</th><th>Payé</th><th>Statut</th><th>Actions</th></tr></thead>
    <tbody>${r.data.map(o=>`<tr>
      <td style="color:var(--t4);font-size:11px">${h(o.numero_commande)}</td>
      <td><div style="display:flex;align-items:center;gap:7px">
        ${o.photo_client?`<img src="${h(o.photo_client)}" style="width:28px;height:28px;border-radius:50%;object-fit:cover;border:2px solid var(--edge)">`:`<div style="width:28px;height:28px;border-radius:50%;background:var(--p);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:#fff">${(o.nom_complet||'?').charAt(0)}</div>`}
        <div><div style="font-weight:600;font-size:12px">${h(o.nom_complet||'—')}</div><div style="font-size:10px;color:var(--t4)">${h(o.tel_client||'')}</div></div>
      </div></td>
      <td style="font-size:11px;max-width:150px">${h(o.resume_plats||'—')}</td>
      <td style="font-size:11px">${h(o.livraison_label)}</td>
      <td style="color:var(--cu);font-weight:600">${o.montant_formate}</td>
      <td><span class="st ${o.statut_paiement}">${o.statut_paiement==='paye'?'Payé':'Non payé'}</span></td>
      <td><select style="background:var(--bg);border:1.5px solid var(--edge);border-radius:6px;padding:4px 8px;font-size:11px;font-family:'Nunito',sans-serif;color:var(--t1);cursor:pointer" onchange="updateStatut(${o.id},this.value)">
        ${opts.map(s=>`<option value="${s}" ${o.statut===s?'selected':''}>${S_LBL[s]}</option>`).join('')}
      </select></td>
      <td style="display:flex;gap:4px">
        ${o.statut_paiement!=='paye'?`<button class="btn btn-ok btn-sm" onclick="marquerPaye(${o.id})">✓ Payé</button>`:''}
        <button class="btn btn-g btn-sm" onclick="openAdminChat(${o.id},'${h(o.nom_complet||'')}')">💬</button>
      </td>
    </tr>`).join('')}</tbody></table>`;
}
async function updateStatut(id,statut){const r=await post({action:'commande_statut',id,statut});toast(r.message,r.success?'s':'e');if(r.success)loadAdminOrders();}
async function marquerPaye(id){const ref=prompt('Référence de paiement :')||'';const r=await post({action:'commande_payer',id,ref});toast(r.message,r.success?'s':'e');if(r.success){loadAdminOrders();loadFinances();}}

// ── Admin Clients ─────────────────────────────────
async function loadClients(){
  document.getElementById('clientsTable').innerHTML=loading();
  const r=await get({action:'clients_list'});
  document.getElementById('cliCount').textContent=(r.data?.length||0)+' clients enregistrés';
  document.getElementById('clientsTable').innerHTML=r.data?.length
    ?`<table><thead><tr><th>Client</th><th>Téléphone</th><th>Quartier</th><th>Commandes</th><th>Total</th><th>Inscrit</th></tr></thead><tbody>
    ${r.data.map(c=>`<tr>
      <td><div style="display:flex;align-items:center;gap:10px">
        ${c.photo_profil?`<img src="${h(c.photo_profil)}" style="width:36px;height:36px;border-radius:50%;object-fit:cover;border:2px solid var(--edge)">`:`<div style="width:36px;height:36px;border-radius:50%;background:var(--p);display:flex;align-items:center;justify-content:center;font-size:15px;font-weight:700;color:#fff">${(c.nom_complet||'?').charAt(0)}</div>`}
        <div><div style="font-weight:600;font-size:13px">${h(c.nom_complet)}</div><div style="font-size:11px;color:var(--t4)">${h(c.email)}</div></div>
      </div></td>
      <td>${h(c.telephone||'—')}</td><td>${h(c.quartier||'Conakry')}</td>
      <td style="font-weight:600">${c.nb_commandes}</td>
      <td style="color:var(--cu);font-weight:600">${c.total_formate}</td>
      <td style="color:var(--t3);font-size:12px">${c.date_formate}</td>
    </tr>`).join('')}</tbody></table>`
    :empty('Aucun client');
}

// ── Admin Menu ────────────────────────────────────
async function loadAdminMenu(){
  document.getElementById('adminMenuCats').innerHTML=loading();
  const [cats,menu]=await Promise.all([get({action:'categories'}),get({action:'menu_admin'})]);
  catsData=cats.data||[];
  const catOpts=catsData.map(c=>`<option value="${c.id}">${h(c.nom)}</option>`).join('');
  document.getElementById('npCat').innerHTML=catOpts;
  document.getElementById('epCat').innerHTML=catOpts;
  document.getElementById('adminMenuCats').innerHTML=catsData.map(cat=>{
    const plats=(menu.data||[]).filter(p=>p.categorie_id==cat.id);
    return`<div class="card" style="margin-bottom:16px">
      <div class="ct">${h(cat.nom)} <span style="font-size:12px;color:var(--t4);font-weight:400">(${plats.length} plat${plats.length!==1?'s':''})</span></div>
      ${plats.length?`<div class="admin-grid">
        ${plats.map(p=>`<div class="admin-plat">
          ${p.image_url?`<img class="admin-plat-img" src="${h(p.image_url)}" alt="${h(p.nom)}">`:`<div class="admin-plat-ph"><svg data-lucide="utensils"></svg></div>`}
          <div class="admin-plat-body">
            <div class="admin-plat-nom">${h(p.nom)}</div>
            <div class="admin-plat-prix">${h(p.prix_formate)} · ${p.temps_prep}min</div>
            <div class="admin-plat-foot">
              <label class="sw"><input type="checkbox" ${p.est_disponible=='1'?'checked':''} onchange="togglePlat(${p.id},this.checked?1:0)"><span class="sw-sl"></span></label>
              <div style="display:flex;gap:4px">
                <button class="btn btn-g btn-sm" onclick="openEditPlat(${p.id})">✏️</button>
                <button class="btn btn-err btn-sm" onclick="deletePlat(${p.id})">🗑</button>
              </div>
            </div>
          </div>
        </div>`).join('')}
      </div>`:`<div style="color:var(--t4);font-size:13px;padding:8px">Aucun plat — <a href="#" onclick="openM('mNewPlat')" style="color:var(--p);font-weight:600">Ajouter →</a></div>`}
    </div>`;
  }).join('');
  lucide.createIcons();
}

async function createPlat(){
  const nom=document.getElementById('npNom').value.trim();
  const prix=document.getElementById('npPrix').value;
  if(!nom||!prix){toast('Nom et prix obligatoires','e');return;}
  btnLoad('savePlatBtn','savePlatTxt','Envoi...');
  const fd=new FormData();
  fd.append('action','plat_create'); fd.append('nom',nom); fd.append('prix',prix);
  fd.append('cat',document.getElementById('npCat').value);
  fd.append('desc',document.getElementById('npDesc').value);
  fd.append('temps',document.getElementById('npTemps').value);
  fd.append('icone',document.getElementById('npIcone').value);
  if(document.getElementById('npPop').checked) fd.append('populaire','1');
  const imgFile=document.getElementById('imgInput').files[0];
  if(imgFile) fd.append('image',imgFile);
  try{
    const res=await fetch(PHP,{method:'POST',body:fd});const r=await res.json();
    btnLoad('savePlatBtn','savePlatTxt','Ajouter au menu',false);
    toast(r.message,r.success?'s':'e');
    if(r.success){closeM('mNewPlat');resetNewPlatForm();loadAdminMenu();}
  }catch(e){btnLoad('savePlatBtn','savePlatTxt','Ajouter au menu',false);toast('Erreur','e');}
}
function resetNewPlatForm(){
  ['npNom','npPrix','npDesc','npIcone'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('npTemps').value='20'; document.getElementById('npPop').checked=false;
  const img=document.getElementById('imgPrev'); img.src=''; img.classList.remove('show');
  const ph=document.getElementById('imgPh'); if(ph) ph.style.display='';
  document.getElementById('imgInput').value='';
}
async function openEditPlat(id){
  const r=await get({action:'menu_admin'}); const p=r.data?.find(x=>x.id==id);
  if(!p){toast('Plat introuvable','e');return;}
  document.getElementById('epId').value=p.id;
  document.getElementById('epNom').value=p.nom||'';
  document.getElementById('epPrix').value=p.prix||0;
  document.getElementById('epDesc').value=p.description||'';
  document.getElementById('epTemps').value=p.temps_prep||15;
  document.getElementById('epIcone').value=p.icone||'';
  document.getElementById('epPop').checked=p.est_populaire=='1';
  document.getElementById('epDispo').checked=p.est_disponible=='1';
  document.getElementById('epCat').value=p.categorie_id||'';
  document.getElementById('epImgActuelle').value=p.image_url||'';
  const ip=document.getElementById('epImgPrev');
  if(p.image_url){ip.src=p.image_url;ip.classList.add('show');}else{ip.src='';ip.classList.remove('show');}
  document.getElementById('epImgInput').value='';
  openM('mEditPlat'); lucide.createIcons();
}
async function savePlatEdit(){
  btnLoad('editPlatBtn','editPlatTxt','Enregistrement...');
  const fd=new FormData();
  fd.append('action','plat_update'); fd.append('id',document.getElementById('epId').value);
  fd.append('nom',document.getElementById('epNom').value); fd.append('prix',document.getElementById('epPrix').value);
  fd.append('cat',document.getElementById('epCat').value); fd.append('desc',document.getElementById('epDesc').value);
  fd.append('temps',document.getElementById('epTemps').value); fd.append('icone',document.getElementById('epIcone').value);
  fd.append('image_actuelle',document.getElementById('epImgActuelle').value);
  if(document.getElementById('epPop').checked) fd.append('populaire','1');
  if(document.getElementById('epDispo').checked) fd.append('disponible','1');
  const imgFile=document.getElementById('epImgInput').files[0];
  if(imgFile) fd.append('image',imgFile);
  try{
    const res=await fetch(PHP,{method:'POST',body:fd});const r=await res.json();
    btnLoad('editPlatBtn','editPlatTxt','Enregistrer',false);
    toast(r.message,r.success?'s':'e');
    if(r.success){closeM('mEditPlat');loadAdminMenu();}
  }catch(e){btnLoad('editPlatBtn','editPlatTxt','Enregistrer',false);toast('Erreur','e');}
}
async function togglePlat(id,val){await post({action:'plat_toggle',id,val});toast(val?'Disponible ✓':'Indisponible','s');setTimeout(loadAdminMenu,300);}
async function deletePlat(id){if(!confirm('Supprimer ce plat définitivement ?'))return;const r=await post({action:'plat_delete',id});toast(r.message,r.success?'s':'e');if(r.success)loadAdminMenu();}

// ── Admin Finances ────────────────────────────────
async function loadFinances(){
  document.getElementById('finTable').innerHTML=loading();
  const [stats,orders]=await Promise.all([get({action:'commandes_stats'}),get({action:'commandes_list'})]);
  if(stats.data){document.getElementById('fRev').textContent=stats.data.revenu_mois;document.getElementById('fAtt').textContent=stats.data.attente_paiement;document.getElementById('fTot').textContent=stats.data.total;document.getElementById('fCli').textContent=stats.data.clients;}
  document.getElementById('finTable').innerHTML=orders.data?.length
    ?`<table><thead><tr><th>Numéro</th><th>Client</th><th>Mode</th><th>Méthode</th><th>Date</th><th>Montant</th><th>Paiement</th><th></th></tr></thead><tbody>
    ${orders.data.map(o=>`<tr>
      <td style="color:var(--t4);font-size:11px">${h(o.numero_commande)}</td>
      <td>${h(o.nom_complet||'—')}</td>
      <td style="font-size:11px">${h(o.livraison_label)}</td>
      <td style="font-size:11px">${h(o.paiement_label)}</td>
      <td style="color:var(--t3);font-size:11px">${o.date_formate}</td>
      <td style="color:var(--cu);font-weight:600">${o.montant_formate}</td>
      <td><span class="st ${o.statut_paiement}">${o.statut_paiement==='paye'?'Payé':'Non payé'}</span></td>
      <td>${o.statut_paiement!=='paye'?`<button class="btn btn-ok btn-sm" onclick="marquerPaye(${o.id})">Confirmer</button>`:''}</td>
    </tr>`).join('')}</tbody></table>`
    :empty('Aucune transaction');
}

// ── Admin Messages ────────────────────────────────
async function loadConversations(){
  document.getElementById('convList').innerHTML=loading();
  const r=await get({action:'conversations_list'});
  document.getElementById('convList').innerHTML=r.data?.length
    ?r.data.map(c=>`<div class="conv-item" onclick="openAdminChat(${c.cid},'${h(c.nom_complet||'')}')">
      ${c.photo_profil?`<img src="${h(c.photo_profil)}" style="width:38px;height:38px;border-radius:50%;object-fit:cover;border:2px solid var(--edge);flex-shrink:0">`:`<div style="width:38px;height:38px;border-radius:50%;background:var(--p);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:15px;color:#fff;flex-shrink:0">${(c.nom_complet||'?').charAt(0)}</div>`}
      <div style="flex:1;min-width:0">
        <div style="font-weight:600;font-size:13px">${h(c.nom_complet||'—')}</div>
        <div style="font-size:11px;color:var(--t4);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${h(c.dernier_msg||'—')}</div>
      </div>
      ${c.non_lus>0?`<span style="background:var(--err);color:#fff;font-size:10px;font-weight:700;padding:2px 7px;border-radius:10px">${c.non_lus}</span>`:''}
    </div>`).join('')
    :empty('Aucune conversation');
}
async function openAdminChat(cid,nom){
  chatCid=cid; document.getElementById('chatNomWrap').textContent=nom; nav('msg-admin');
  const r=await get({action:'messages_list',cid});
  const box=document.getElementById('adminChatBox');
  box.innerHTML=r.data?.length?r.data.map(m=>`<div class="cm ${m.role_expediteur}"><div class="cb">${h(m.contenu)}</div><div class="cm-meta">${h(m.exp_nom||m.role_expediteur)} — ${m.heure}</div></div>`).join(''):empty('Aucun message');
  box.scrollTop=box.scrollHeight;
}
async function sendAdminMsg(){
  const inp=document.getElementById('adminChatInp');const contenu=inp.value.trim();
  if(!contenu||!chatCid)return;
  const r=await post({action:'message_send',cid:chatCid,contenu});
  if(!r.success){toast(r.message,'e');return;}
  inp.value=''; openAdminChat(chatCid,document.getElementById('chatNomWrap').textContent);
}

// ── Admin Params ──────────────────────────────────
async function loadParamProfile(){
  const r=await get({action:'profil_get'});
  if(r.data){
    document.getElementById('pNom').value=r.data.nom_complet||'';
    document.getElementById('pEmail').value=r.data.email||'';
    document.getElementById('pTel').value=r.data.telephone||'';
    document.getElementById('adminProfilName').textContent=r.data.nom_complet||'—';
    document.getElementById('adminProfilEmail').textContent=r.data.email||'—';
    const ava=document.getElementById('adminProfilAva');
    if(r.data.photo_profil){ava.innerHTML=`<img src="${h(r.data.photo_profil)}" alt="profil">`;}
    else{ava.innerHTML=`<span id="adminProfilLetter">${(r.data.nom_complet||'A').charAt(0)}</span>`;}
  }
}
async function saveProfile(){
  const r=await post({action:'profil_update',nom:document.getElementById('pNom').value,telephone:document.getElementById('pTel').value,quartier:'',ville:'Conakry'});
  toast(r.message,r.success?'s':'e');
  if(r.success) document.getElementById('adminProfilName').textContent=document.getElementById('pNom').value;
}
async function changePass(curId,newId,confId){
  const r=await post({action:'password_change',current:document.getElementById(curId).value,new:document.getElementById(newId).value,confirm:document.getElementById(confId).value});
  toast(r.message,r.success?'s':'e');
}

// ── Client Home ───────────────────────────────────
async function loadClientHome(){
  const [stats,orders]=await Promise.all([get({action:'commandes_stats'}),get({action:'commandes_list'})]);
  if(stats.data){document.getElementById('csTot').textContent=stats.data.total;document.getElementById('csDone').textContent=stats.data.livrees||0;document.getElementById('csAct').textContent=stats.data.en_cours||0;document.getElementById('csAmt').textContent=stats.data.montant_formate;}
  document.getElementById('cHomeOrders').innerHTML=orders.data?.length
    ?`<table><thead><tr><th>Numéro</th><th>Plats</th><th>Mode</th><th>Montant</th><th>Statut</th><th></th></tr></thead><tbody>
    ${orders.data.slice(0,5).map(o=>`<tr>
      <td style="color:var(--t4);font-size:11px">${h(o.numero_commande)}</td>
      <td style="font-size:11px">${h(o.resume_plats||'—')}</td>
      <td style="font-size:11px">${h(o.livraison_label)}</td>
      <td style="color:var(--cu);font-weight:600">${o.montant_formate}</td>
      <td><span class="st ${o.statut}">${S_LBL[o.statut]||o.statut}</span></td>
      <td>${o.statut_paiement!=='paye'&&o.methode_paiement!=='especes'?`<button class="btn btn-amber btn-sm" onclick="ouvrirPaiement(${o.id},${o.montant_total},'${o.methode_paiement}')">Payer</button>`:''}</td>
    </tr>`).join('')}</tbody></table>`
    :`<div style="text-align:center;color:var(--t4);padding:30px">Aucune commande. <a href="#" onclick="nav('commander')" style="color:var(--p);font-weight:600">Voir notre menu →</a></div>`;
}

// ── Client Menu ───────────────────────────────────
async function loadMenu(){
  const [cats,menu]=await Promise.all([get({action:'categories'}),get({action:'menu'})]);
  catsData=cats.data||[]; menuData=menu.data||[];
  document.getElementById('catTabs').innerHTML=
    `<div class="cat-tab active" onclick="filterCat(this,0)"><svg data-lucide="utensils" width="13" height="13"></svg>Tout</div>`+
    catsData.map(c=>`<div class="cat-tab" onclick="filterCat(this,${c.id})">${h(c.nom)}</div>`).join('');
  renderMenu(menuData);
  lucide.createIcons();
}
function filterCat(el,catId){
  document.querySelectorAll('.cat-tab').forEach(t=>t.classList.remove('active'));
  el.classList.add('active');
  renderMenu(catId===0?menuData:menuData.filter(p=>p.categorie_id==catId));
}
function renderMenu(plats){
  if(!plats.length){document.getElementById('menuGrid').innerHTML=`<div style="grid-column:1/-1">${empty('Aucun plat dans cette catégorie')}</div>`;return;}
  document.getElementById('menuGrid').innerHTML=plats.map(p=>{
    const qty=panier[p.id]?.qty||0;
    return`<div class="plat-card">
      ${p.est_populaire=='1'?`<div class="plat-badge"><svg data-lucide="star" width="10" height="10"></svg>Populaire</div>`:''}
      <div class="plat-img-wrap">
        ${p.image_url?`<img class="plat-img" src="${h(p.image_url)}" alt="${h(p.nom)}">`:`<div class="plat-img-ph"><svg data-lucide="utensils"></svg><span style="font-size:11px">${h(p.categorie_nom||'')}</span></div>`}
      </div>
      <div class="plat-body">
        <div class="plat-cat">${h(p.categorie_nom||'')}</div>
        <div class="plat-nom">${h(p.nom)}</div>
        <div class="plat-desc">${h(p.description||'')}</div>
        <div class="plat-footer">
          <div><div class="plat-prix">${h(p.prix_formate)}</div><div class="plat-time"><svg data-lucide="clock" width="11" height="11"></svg>${p.temps_prep} min</div></div>
          <div class="qty-row">
            <button class="qty-btn" onclick="modQty(${p.id},${p.prix},'${h(p.nom)}',-1)" style="${qty>0?'':'opacity:.4'}">−</button>
            <span class="qty-val" id="qty-${p.id}" style="${qty>0?'color:var(--p);font-weight:800':'color:var(--t3)'}">${qty}</span>
            <button class="qty-btn" onclick="modQty(${p.id},${p.prix},'${h(p.nom)}',1)">+</button>
          </div>
        </div>
      </div>
    </div>`;
  }).join('');
  lucide.createIcons();
}

// ── Panier ────────────────────────────────────────
function modQty(id,prix,nom,delta){
  if(!panier[id]) panier[id]={qty:0,prix,nom};
  panier[id].qty=Math.max(0,panier[id].qty+delta);
  if(panier[id].qty===0) delete panier[id];
  const el=document.getElementById('qty-'+id); if(el) el.textContent=panier[id]?.qty||0;
  updatePanierUI();
}
function updatePanierUI(){
  const items=Object.entries(panier);
  const total=items.reduce((s,[,v])=>s+v.prix*v.qty,0);
  const count=items.reduce((s,[,v])=>s+v.qty,0);
  const pf=document.getElementById('panierFixed'); if(pf) pf.style.display=count>0&&user?.role==='client'?'block':'none';
  const pc=document.getElementById('panierCount'); if(pc) pc.textContent=count;
  const pt=document.getElementById('panierTotalBtn'); if(pt) pt.textContent=count>0?'· '+fmtGNF(total):'';
}
function openPanier(){
  const items=Object.entries(panier);
  const total=items.reduce((s,[,v])=>s+v.prix*v.qty,0);
  document.getElementById('panierTotalModal').textContent=fmtGNF(total);
  document.getElementById('cmdTel').value=user?.telephone||'';
  document.getElementById('panierItems').innerHTML=items.length
    ?items.map(([id,v])=>`<div class="p-item">
      <div><div class="p-nom">${h(v.nom)}</div><div class="p-detail">${fmtGNF(v.prix)} × ${v.qty}</div></div>
      <div style="display:flex;align-items:center;gap:10px">
        <div class="qty-row">
          <button class="qty-btn" onclick="modQty(${id},${v.prix},'${h(v.nom)}',-1);refreshPanierModal()">−</button>
          <span class="qty-val">${v.qty}</span>
          <button class="qty-btn" onclick="modQty(${id},${v.prix},'${h(v.nom)}',1);refreshPanierModal()">+</button>
        </div>
        <span class="p-prix">${fmtGNF(v.prix*v.qty)}</span>
      </div>
    </div>`).join('')
    :`<div style="text-align:center;color:var(--t4);padding:30px">Votre panier est vide</div>`;
  openM('mPanier');
}
function refreshPanierModal(){
  const items=Object.entries(panier);
  document.getElementById('panierTotalModal').textContent=fmtGNF(items.reduce((s,[,v])=>s+v.prix*v.qty,0));
  updatePanierUI();
}
function selMode(el,mode){
  document.querySelectorAll('.mode-opt').forEach(p=>p.classList.remove('sel'));
  el.classList.add('sel'); document.getElementById('cmdMode').value=mode;
  document.getElementById('adresseGroup').style.display=mode==='livraison'?'block':'none';
}
function selPay(el,pay){
  document.querySelectorAll('.pay-opt').forEach(p=>p.classList.remove('sel'));
  el.classList.add('sel'); document.getElementById('cmdPay').value=pay;
}
async function passerCommande(){
  const items=Object.entries(panier);
  if(!items.length){toast('Votre panier est vide','e');return;}
  const mode=document.getElementById('cmdMode').value;
  const adresse=document.getElementById('cmdAdresse').value.trim();
  const tel=document.getElementById('cmdTel').value.trim();
  const methode=document.getElementById('cmdPay').value;
  const notes=document.getElementById('cmdNotes').value;
  if(mode==='livraison'&&!adresse){toast('Adresse de livraison requise','e');return;}
  btnLoad('cmdBtn','cmdBtnTxt','Traitement...');
  const r=await post({action:'commande_create',panier:JSON.stringify(items.map(([id,v])=>({id,qty:v.qty}))),mode,adresse,telephone:tel,methode,notes});
  btnLoad('cmdBtn','cmdBtnTxt','Confirmer la commande',false);
  if(!r.success){toast(r.message,'e');return;}
  payOrderId=r.data.commande_id;
  panier={}; updatePanierUI();
  document.querySelectorAll('[id^="qty-"]').forEach(el=>el.textContent='0');
  closeM('mPanier');
  if(methode!=='especes') afficherPaiement(methode,r.data.montant);
  else{toast('Commande passée ! Payez au comptoir/livreur.','s');loadClientHome();}
}
function ouvrirPaiement(id,montant,methode){payOrderId=id;afficherPaiement(methode,montant);}
function afficherPaiement(methode,montant){
  const cfg=PAY_INFO[methode]||PAY_INFO.especes;
  document.getElementById('payTitle').textContent=cfg.titre;
  document.getElementById('payEmoji').textContent=cfg.emoji;
  document.getElementById('payMontant').textContent=fmtGNF(montant);
  document.getElementById('payInstr').innerHTML=cfg.instr;
  document.getElementById('payRef').value='';
  openM('mPay');
}
async function soumettrePaiement(){
  const ref=document.getElementById('payRef').value.trim();
  const r=await post({action:'commande_ref',id:payOrderId,ref});
  toast(r.message,r.success?'s':'e');
  if(r.success){closeM('mPay');loadClientHome();loadMyOrders();}
}

// ── Client Mes Commandes ──────────────────────────
async function loadMyOrders(){
  document.getElementById('myOrders').innerHTML=loading();
  const r=await get({action:'commandes_list'});
  document.getElementById('myOrders').innerHTML=r.data?.length
    ?`<table><thead><tr><th>Numéro</th><th>Plats</th><th>Mode</th><th>Date</th><th>Montant</th><th>Statut</th><th>Paiement</th><th></th></tr></thead><tbody>
    ${r.data.map(o=>`<tr>
      <td style="color:var(--t4);font-size:11px">${h(o.numero_commande)}</td>
      <td style="font-size:11px;max-width:150px">${h(o.resume_plats||'—')}</td>
      <td style="font-size:11px">${h(o.livraison_label)}</td>
      <td style="color:var(--t3);font-size:11px">${o.date_formate}</td>
      <td style="color:var(--cu);font-weight:600">${o.montant_formate}</td>
      <td><span class="st ${o.statut}">${S_LBL[o.statut]||o.statut}</span></td>
      <td><span class="st ${o.statut_paiement}">${o.statut_paiement==='paye'?'Payé':'Non payé'}</span></td>
      <td>${o.statut_paiement!=='paye'&&o.methode_paiement!=='especes'?`<button class="btn btn-amber btn-sm" onclick="ouvrirPaiement(${o.id},${o.montant_total},'${o.methode_paiement}')">Payer</button>`:''}</td>
    </tr>`).join('')}</tbody></table>`
    :`<div style="text-align:center;color:var(--t4);padding:36px">Aucune commande. <a href="#" onclick="nav('commander')" style="color:var(--p);font-weight:600">Commander →</a></div>`;
}

// ── Client Messages ───────────────────────────────
async function loadMyConvList(){
  const r=await get({action:'commandes_list'});
  document.getElementById('myConvList').innerHTML=r.data?.length
    ?r.data.map(o=>`<div class="conv-item" onclick="openClientChat(${o.id},'${h(o.numero_commande)}')">
      <div style="flex:1"><div style="font-weight:600;font-size:13px">${h(o.numero_commande)}</div>
      <div style="font-size:11px;color:var(--t4)">${h(o.resume_plats||'—')}</div>
      <span class="st ${o.statut}" style="font-size:10px;margin-top:3px;display:inline-flex">${S_LBL[o.statut]||o.statut}</span>
      </div></div>`).join('')
    :empty('Aucune commande');
}
async function openClientChat(cid,titre){
  chatCid=cid; document.getElementById('cChatTitle').textContent=titre;
  const r=await get({action:'messages_list',cid});
  const box=document.getElementById('clientChatBox');
  box.innerHTML=r.data?.length?r.data.map(m=>`<div class="cm ${m.role_expediteur}"><div class="cb">${h(m.contenu)}</div><div class="cm-meta">${m.role_expediteur==='admin'?'Calvin Food':'Vous'} — ${m.heure}</div></div>`).join(''):empty('Écrivez pour contacter Calvin Food');
  box.scrollTop=box.scrollHeight;
}
async function sendClientMsg(){
  const inp=document.getElementById('cChatInp'); const contenu=inp.value.trim();
  if(!contenu||!chatCid){toast('Sélectionnez une commande','e');return;}
  const r=await post({action:'message_send',cid:chatCid,contenu});
  if(!r.success){toast(r.message,'e');return;}
  inp.value=''; openClientChat(chatCid,document.getElementById('cChatTitle').textContent);
}

// ── Client Mon Compte ─────────────────────────────
async function loadClientProfile(){
  const r=await get({action:'profil_get'});
  if(r.data){
    document.getElementById('cNom').value=r.data.nom_complet||'';
    document.getElementById('cEmail').value=r.data.email||'';
    document.getElementById('cTel').value=r.data.telephone||'';
    document.getElementById('cQuartier').value=r.data.quartier||'';
    document.getElementById('clientProfilName').textContent=r.data.nom_complet||'—';
    document.getElementById('clientProfilEmail').textContent=r.data.email||'—';
    const ava=document.getElementById('clientProfilAva');
    if(r.data.photo_profil){ava.innerHTML=`<img src="${h(r.data.photo_profil)}" alt="profil">`;}
    else{ava.innerHTML=`<span id="clientProfilLetter">${(r.data.nom_complet||'C').charAt(0)}</span>`;}
  }
}
async function saveClientProfile(){
  const r=await post({action:'profil_update',nom:document.getElementById('cNom').value,telephone:document.getElementById('cTel').value,quartier:document.getElementById('cQuartier').value,ville:'Conakry'});
  toast(r.message,r.success?'s':'e');
  if(r.success) document.getElementById('clientProfilName').textContent=document.getElementById('cNom').value;
}

// ── Utilitaires ───────────────────────────────────
function fmtGNF(n){n=parseInt(n)||0;if(n>=1000000)return(n/1000000).toFixed(1).replace('.0','')+'M GNF';if(n>=1000)return Math.round(n/1000)+'K GNF';return n+' GNF';}
function h(s){if(!s)return'';return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function previewImg(input,previewId,phId){
  const file=input.files[0]; if(!file)return;
  const reader=new FileReader();
  reader.onload=e=>{
    const img=document.getElementById(previewId); img.src=e.target.result; img.classList.add('show');
    if(phId){const ph=document.getElementById(phId);if(ph)ph.style.display='none';}
  };
  reader.readAsDataURL(file);
}
function openM(id){document.getElementById(id)?.classList.add('open');lucide.createIcons();}
function closeM(id){document.getElementById(id)?.classList.remove('open');}
function toast(msg,type='s'){
  const el=document.getElementById('toast'),im=document.getElementById('toastIcon'),tm=document.getElementById('toastMsg');
  tm.textContent=msg; el.className=type+' show';
  clearTimeout(el._t); el._t=setTimeout(()=>el.classList.remove('show'),4000);
}
function loading(){return`<div class="loading"><div class="spin"></div> Chargement...</div>`;}
function empty(m){return`<div style="text-align:center;color:var(--t4);padding:32px;font-size:13px">${m}</div>`;}
function btnLoad(bId,tId,txt,load=true){
  const b=document.getElementById(bId),t=document.getElementById(tId);
  if(b)b.disabled=load;
  if(t)t.innerHTML=load?`<span class="spin"></span> ${txt}`:txt;
}
document.querySelectorAll('.overlay').forEach(o=>{o.addEventListener('click',e=>{if(e.target===o)o.classList.remove('open');});});

// Init Lucide icons
document.addEventListener('DOMContentLoaded',()=>lucide.createIcons());
</script>
</body>
</html>
