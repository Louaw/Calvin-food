<?php
// fix_admin.php — Calvin Food
// Ouvrir : http://localhost/calvinfood/fix_admin.php
// Supprimer après utilisation !

$pdo = new PDO("mysql:host=localhost;dbname=calvinfood;charset=utf8mb4","root","",
    [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);

$mdp   = "sidiki224";
$email = "admin@calvinfood.gn";
$hash  = password_hash($mdp, PASSWORD_BCRYPT);

$st = $pdo->prepare("SELECT id FROM utilisateurs WHERE email=?");
$st->execute([$email]);
if ($st->fetch()) {
    $pdo->prepare("UPDATE utilisateurs SET mot_de_passe=?, role='admin' WHERE email=?")->execute([$hash,$email]);
} else {
    $pdo->prepare("INSERT INTO utilisateurs (nom_complet,email,telephone,mot_de_passe,role) VALUES('Calvin Admin',?,'+224620000000',?,'admin')")->execute([$email,$hash]);
}

$verif = $pdo->prepare("SELECT mot_de_passe FROM utilisateurs WHERE email=?");
$verif->execute([$email]); $row=$verif->fetch();
$ok = password_verify($mdp, $row['mot_de_passe']);

echo "<style>body{font-family:sans-serif;background:#0f0a04;color:#fef3c7;padding:40px;} .box{background:#1e1208;border:1px solid rgba(255,200,100,.1);border-radius:14px;padding:28px;max-width:500px;margin:auto;}</style>";
echo "<div class='box'><h2 style='color:#f59e0b'>🍽️ Calvin Food — Fix Admin</h2>";
echo $ok ? "<p style='color:#10b981;font-size:16px'>✅ Mot de passe <b>sidiki224</b> configuré !</p>" : "<p style='color:#ef4444'>❌ Erreur</p>";
echo "<p style='color:#a8956e'>Email : <b style='color:#f59e0b'>$email</b></p>";
echo "<p style='color:#a8956e'>Mot de passe : <b style='color:#f59e0b'>$mdp</b></p><br>";
echo "<a href='index.php' style='background:#f59e0b;color:#000;padding:10px 20px;border-radius:8px;text-decoration:none;font-weight:700'>→ Aller sur l'application</a>";
echo "<p style='color:#78716c;font-size:12px;margin-top:20px'>⚠️ Supprime ce fichier fix_admin.php après !</p></div>";
?>
