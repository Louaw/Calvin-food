# Calvin Food — Guide complet
## Hébergement gratuit + Convaincre les clients

---

## PARTIE 1 — HÉBERGER GRATUITEMENT

### Option A : InfinityFree (Recommandé pour débuter)
**Site :** https://infinityfree.com

**Ce qu'il offre gratuitement :**
- Hébergement PHP + MySQL illimité
- Nom de domaine gratuit (ex: calvinfood.rf.gd)
- SSL (HTTPS) inclus
- Aucune carte bancaire requise

**Étapes :**
1. Créer un compte sur infinityfree.com
2. Créer un nouveau site → noter les infos MySQL (host, user, password, db)
3. Modifier index.php : remplacer les 4 lignes en haut :
   ```php
   $DB_HOST = "sql...infinityfree.com";  // donné par InfinityFree
   $DB_USER = "epiz_xxxxx";              // donné par InfinityFree
   $DB_PASS = "votre_mot_de_passe";      // donné par InfinityFree
   $DB_NAME = "epiz_xxxxx_calvinfood";   // créer dans phpMyAdmin
   ```
4. Aller dans phpMyAdmin → Importer database.sql
5. Uploader index.php dans le dossier htdocs via File Manager
6. Créer le dossier "uploads" dans htdocs
7. Votre site est en ligne !

---

### Option B : Awardspace (Très fiable)
**Site :** https://www.awardspace.com/free-hosting/

- PHP 8 + MySQL gratuit
- 1GB espace, 5GB bande passante/mois
- Domaine gratuit .atspace.com

---

### Option C : 000webhost (Populaire)
**Site :** https://www.000webhost.com

- PHP + MySQL gratuit
- 300MB espace, 3GB bande passante
- Interface très simple

---

### Option D : Votre propre domaine (.com) pour 5 000 GNF/mois
Si vous voulez calvinfood.com, utiliser **Namecheap** + **Cloudflare Pages** :
- Domaine .com ≈ 5 000 GNF/an sur namecheap.com
- Hébergement sur Hostinger Starter ≈ 15 000 GNF/mois

---

## PARTIE 2 — CONVAINCRE LES CLIENTS

### Stratégie 1 : WhatsApp Business (Gratuit, très efficace à Conakry)

**Créer votre profil Calvin Food :**
- Photo de profil : logo Calvin Food
- Description : "🍽 Restaurant Calvin Food · Livraison rapide · Commander sur [votre-lien]"
- Lien du site dans la bio

**Message de lancement à envoyer à vos contacts :**
```
Bonjour ! 👋

Calvin Food est maintenant en ligne ! 🎉

✅ Commandez vos plats préférés depuis votre téléphone
🛵 Livraison rapide à domicile à Conakry
💳 Payez par Orange Money *144# ou espèces
🍽 Riz sauce feuille, poulet braisé, thiéboudienne...

👉 Commandez maintenant : [votre-lien]

Partagez avec vos amis ! 🙏
```

---

### Stratégie 2 : Facebook & Instagram

**Publication de lancement :**
```
🍽 CALVIN FOOD est OUVERT !

Nous livrons maintenant directement à votre porte 🚪

📱 Commandez en ligne 24h/24 sur [lien]
⏱ Livraison en 20-40 minutes
💰 Paiement Orange Money ou espèces

Nos spécialités :
• Riz Sauce Feuille — 25 000 GNF
• Poulet Braisé Entier — 45 000 GNF  
• Thiéboudienne — 32 000 GNF
• Jus de Bissap — 8 000 GNF

📍 Conakry · Livraison disponible
📞 [votre numéro]

Taguez un ami qui a faim ! 🤤👇
#CalvinFood #Conakry #RestaurantConakry #LivraisonConakry
```

---

### Stratégie 3 : Offre de lancement (7 premiers jours)

Créer une promotion pour attirer les premiers clients :

**Idée 1 — Réduction première commande :**
> "Première commande : -15% avec le code BIENVENUE"
> *(vous appliquez la réduction manuellement en confirmant la commande)*

**Idée 2 — Livraison gratuite :**
> "Livraison GRATUITE pour toute commande de +30 000 GNF — offre limitée !"

**Idée 3 — Menu découverte :**
> "Menu découverte : 1 plat + 1 jus = 25 000 GNF au lieu de 33 000 GNF"

---

### Stratégie 4 : Bouche à oreille / Ambassadeurs

Proposer à vos premiers clients :
> "Partagez notre lien à 3 amis qui commandent → votre prochain jus OFFERT !"

---

### Stratégie 5 : Groupes WhatsApp de Conakry

Rejoindre et publier dans :
- Groupes de quartier (Kaloum, Ratoma, Matoto, Dixinn, Matam)
- Groupes d'entreprises et bureaux
- Groupes d'étudiants (universités)

---

## PARTIE 3 — APRÈS LE LANCEMENT

### Ce que vous devez faire chaque jour :

| Tâche | Fréquence |
|-------|-----------|
| Vérifier les nouvelles commandes | Matin, midi, soir |
| Répondre aux messages clients | Dans les 30 min |
| Confirmer les paiements Orange Money | Dès réception |
| Publier une photo de plat du jour | 1x/jour sur Facebook |
| Mettre à jour les disponibilités | Chaque matin |

---

### Informations à configurer dans l'application :

1. **Numéro Orange Money :** déjà configuré → +224 628 37 32 35
2. **Ajouter vos vraies photos** de plats dans Admin → Menu
3. **Mettre à jour les prix** si nécessaire
4. **Activer/désactiver les plats** selon les stocks du jour

---

## RÉSUMÉ RAPIDE

```
AUJOURD'HUI :
1. Aller sur infinityfree.com → créer compte
2. Importer database.sql dans phpMyAdmin
3. Mettre les identifiants MySQL dans index.php
4. Uploader index.php + créer dossier uploads/
5. Tester sur mobile

CETTE SEMAINE :
6. Envoyer le lien à tous vos contacts WhatsApp
7. Publier sur Facebook/Instagram
8. Prendre de belles photos de vos plats
9. Ajouter les photos dans le menu admin

```

**Votre site sera en ligne, fonctionnel, et prêt à recevoir des commandes ! 🚀**
