-- ================================================================
-- CALVIN FOOD — Base de données MySQL
-- Importer dans : http://localhost/phpmyadmin
-- ================================================================

CREATE DATABASE IF NOT EXISTS calvinfood CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE calvinfood;

-- TABLE UTILISATEURS
CREATE TABLE IF NOT EXISTS utilisateurs (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  nom_complet   VARCHAR(150) NOT NULL,
  email         VARCHAR(150) NOT NULL UNIQUE,
  telephone     VARCHAR(30),
  mot_de_passe  VARCHAR(255) NOT NULL,
  role          ENUM('admin','client') DEFAULT 'client',
  quartier      VARCHAR(100),
  ville         VARCHAR(100) DEFAULT 'Conakry',
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABLE CATEGORIES
CREATE TABLE IF NOT EXISTS categories (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  nom        VARCHAR(100) NOT NULL,
  icone      VARCHAR(10)  DEFAULT '',
  ordre      INT          DEFAULT 0,
  est_active TINYINT(1)   DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABLE PLATS
CREATE TABLE IF NOT EXISTS plats (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  categorie_id   INT,
  nom            VARCHAR(150) NOT NULL,
  description    TEXT,
  prix           INT NOT NULL DEFAULT 0,
  temps_prep     INT DEFAULT 15,
  icone          VARCHAR(10) DEFAULT '',
  est_disponible TINYINT(1)  DEFAULT 1,
  est_populaire  TINYINT(1)  DEFAULT 0,
  created_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (categorie_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABLE COMMANDES
CREATE TABLE IF NOT EXISTS commandes (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  numero_commande     VARCHAR(20) UNIQUE,
  client_id           INT,
  mode_livraison      ENUM('livraison','sur_place','emporter') DEFAULT 'sur_place',
  statut              ENUM('en_attente','confirme','en_preparation','pret','en_livraison','livre','annule') DEFAULT 'en_attente',
  montant_total       INT NOT NULL DEFAULT 0,
  methode_paiement    ENUM('orange_money','mtn_momo','especes','virement') DEFAULT 'especes',
  statut_paiement     ENUM('non_paye','paye','rembourse') DEFAULT 'non_paye',
  ref_paiement        VARCHAR(100),
  adresse_livraison   TEXT,
  notes_client        TEXT,
  notes_admin         TEXT,
  telephone_livraison VARCHAR(30),
  created_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at          DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (client_id) REFERENCES utilisateurs(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABLE DETAILS COMMANDE
CREATE TABLE IF NOT EXISTS commande_details (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  commande_id   INT NOT NULL,
  plat_id       INT,
  nom_plat      VARCHAR(150),
  prix_unitaire INT NOT NULL DEFAULT 0,
  quantite      INT NOT NULL DEFAULT 1,
  sous_total    INT NOT NULL DEFAULT 0,
  FOREIGN KEY (commande_id) REFERENCES commandes(id) ON DELETE CASCADE,
  FOREIGN KEY (plat_id)     REFERENCES plats(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABLE TRANSACTIONS
CREATE TABLE IF NOT EXISTS transactions (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  commande_id   INT,
  client_id     INT,
  montant       INT NOT NULL DEFAULT 0,
  methode       VARCHAR(50) NOT NULL,
  statut        ENUM('en_attente','succes','echec') DEFAULT 'en_attente',
  ref_operateur VARCHAR(100),
  telephone     VARCHAR(30),
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (commande_id) REFERENCES commandes(id) ON DELETE SET NULL,
  FOREIGN KEY (client_id)   REFERENCES utilisateurs(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABLE MESSAGES
CREATE TABLE IF NOT EXISTS messages (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  commande_id     INT,
  expediteur_id   INT,
  role_expediteur ENUM('admin','client') NOT NULL,
  contenu         TEXT NOT NULL,
  lu              TINYINT(1) DEFAULT 0,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (commande_id)   REFERENCES commandes(id)    ON DELETE CASCADE,
  FOREIGN KEY (expediteur_id) REFERENCES utilisateurs(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABLE NOTIFICATIONS
CREATE TABLE IF NOT EXISTS notifications (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT,
  titre      VARCHAR(200) NOT NULL,
  corps      TEXT         NOT NULL,
  type       ENUM('info','commande','paiement','message') DEFAULT 'info',
  lu         TINYINT(1)   DEFAULT 0,
  created_at DATETIME     DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES utilisateurs(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ================================================================
-- DONNEES DE DEPART
-- ================================================================

-- Admin : admin@calvinfood.gn / sidiki224
INSERT INTO utilisateurs (nom_complet, email, telephone, mot_de_passe, role) VALUES
('Calvin Admin', 'admin@calvinfood.gn', '+224620000000',
 '$2y$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p722my/gFEQfEfRIJ5X3Uy', 'admin');

-- Client demo : client@gmail.com / Client1234!
INSERT INTO utilisateurs (nom_complet, email, telephone, mot_de_passe, role, quartier) VALUES
('Mamadou Client', 'client@gmail.com', '+224621000001',
 '$2y$10$TKh8H1.PkfKlmB4SDbFGi.pHkVDFbm36RL.xCxm7KLXeGlqNDumC', 'client', 'Kaloum');

-- Categories
INSERT INTO categories (nom, icone, ordre) VALUES
('Plats Africains',         'PA', 1),
('Grillades',               'GR', 2),
('Poissons & Fruits de mer','PO', 3),
('Sandwichs & Fast Food',   'SF', 4),
('Pizzas',                  'PI', 5),
('Boissons & Jus',          'BO', 6);

-- Plats
INSERT INTO plats (categorie_id, nom, description, prix, temps_prep, icone, est_disponible, est_populaire) VALUES
(1,'Riz Sauce Feuille',     'Riz blanc avec sauce feuilles de manioc et viande de boeuf',     25000,20,'PA',1,1),
(1,'Riz Gras au Poulet',    'Riz cuit dans une sauce tomate avec poulet entier',               30000,25,'PA',1,1),
(1,'To Sauce Gombo',        'To de mais servi avec sauce gombo et poisson fume',               20000,20,'PA',1,0),
(1,'Attieke Poisson Braise','Attieke avec poisson braise et salade fraiche',                   28000,20,'PA',1,0),
(1,'Fonio au Poulet',       'Fonio prepare avec poulet et legumes frais',                      22000,20,'PA',1,0),
(2,'Poulet Braise Entier',  'Poulet entier marine et braise au charbon de bois',               45000,40,'GR',1,1),
(2,'Cotes de Boeuf',        'Cotes de boeuf marinees grillees, servies avec frites',           55000,35,'GR',1,0),
(2,'Brochettes de Mouton',  'Brochettes de mouton marinees aux epices africaines',             35000,25,'GR',1,1),
(2,'Poulet en Morceaux',    'Morceaux de poulet braise avec sauce pimentee',                   30000,30,'GR',1,0),
(3,'Barracuda Braise',      'Barracuda frais braise avec sauce tomate et oignons',             40000,30,'PO',1,1),
(3,'Crevettes Sautees',     'Crevettes geantes sautees a l ail et au beurre',                  50000,20,'PO',1,0),
(3,'Capitaine Frit',        'Filet de capitaine pane et frit, servi avec frites maison',       38000,25,'PO',1,0),
(3,'Thieboudienne',         'Riz au poisson senegalais aux legumes varies',                    32000,35,'PO',1,1),
(4,'Sandwich Poulet',       'Baguette croustillante avec poulet grille et sauce maison',       15000,10,'SF',1,1),
(4,'Burger Calvin Special', 'Double steak, fromage fondu, bacon, sauce maison',               20000,15,'SF',1,1),
(4,'Hot Dog',               'Saucisse grillee dans pain moelleux avec moutarde ketchup',      12000,10,'SF',1,0),
(4,'Sandwich Thon',         'Baguette avec thon, mayonnaise, tomates et cornichons',          13000,10,'SF',1,0),
(5,'Pizza Margherita',      'Sauce tomate, mozzarella, basilic frais',                        35000,25,'PI',1,0),
(5,'Pizza Poulet BBQ',      'Sauce BBQ, poulet grille, oignons, mozzarella',                  40000,25,'PI',1,1),
(5,'Pizza Fruits de Mer',   'Crevettes, calamars, sauce blanche, mozzarella',                 45000,30,'PI',1,0),
(5,'Pizza 4 Fromages',      'Mozzarella, emmental, chevre, parmesan',                         42000,25,'PI',1,0),
(6,'Jus de Bissap',         'Jus de fleurs d hibiscus frais et sucre',                         8000, 5,'BO',1,1),
(6,'Jus de Gingembre',      'Jus de gingembre frais legerement sucre',                         8000, 5,'BO',1,0),
(6,'Jus de Ditakh',         'Jus de fruit ditakh naturel et rafraichissant',                    8000, 5,'BO',1,0),
(6,'Eau Minerale',          'Eau minerale fraiche 1.5L',                                        5000, 2,'BO',1,0),
(6,'Coca-Cola / Fanta',     'Boisson gazeuse 33cl bien fraiche',                               6000, 2,'BO',1,0);

-- Commandes demo
INSERT INTO commandes (numero_commande,client_id,mode_livraison,statut,montant_total,methode_paiement,statut_paiement,adresse_livraison) VALUES
('CF-0001',2,'livraison','en_preparation',75000,'orange_money','paye','Kaloum, pres du marche central'),
('CF-0002',2,'sur_place','livre',55000,'especes','paye',NULL),
('CF-0003',2,'emporter','en_attente',40000,'mtn_momo','non_paye',NULL);

INSERT INTO commande_details (commande_id,plat_id,nom_plat,prix_unitaire,quantite,sous_total) VALUES
(1,6,'Poulet Braise Entier',45000,1,45000),(1,23,'Jus de Bissap',8000,1,8000),
(2,7,'Cotes de Boeuf',55000,1,55000),
(3,10,'Barracuda Braise',40000,1,40000);
